import React, { useEffect, useState } from 'react';
import { collection, addDoc, query, where, getDocs } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { useAuth } from '../context/AuthContext';
import { logAuditEvent } from '../lib/auditLogger';
import { StaffApplication, ApplicationCategory, ApplicationQueue, QUESTIONS } from '../types';
import { Send, AlertCircle, CheckCircle2, Info, ArrowRight, ShieldCheck, Clock, ChevronDown, Loader2 } from 'lucide-react';
import { SubmissionSuccess } from '../components/SubmissionSuccess';

interface StaffApplyPageProps {
  onNavigate: (page: string) => void;
  onOpenAuth: () => void;
  defaultCategory?: ApplicationCategory;
}

export const StaffApplyPage: React.FC<StaffApplyPageProps> = ({ onNavigate, onOpenAuth, defaultCategory }) => {
  const { currentUser, userProfile } = useAuth();
  const [existingApp, setExistingApp] = useState<StaffApplication | null>(null);
  const [checkingExisting, setCheckingExisting] = useState(true);
  const [category, setCategory] = useState<ApplicationCategory>(defaultCategory || 'Staff Application');
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showSuccessOverlay, setShowSuccessOverlay] = useState(false);

  useEffect(() => {
    if (defaultCategory) {
      setCategory(defaultCategory);
    }
  }, [defaultCategory]);

  useEffect(() => {
    async function checkExisting() {
      if (!currentUser) { setCheckingExisting(false); return; }
      try {
        const q = query(collection(db, 'applications'), where('applicantUid', '==', currentUser.uid));
        const snap = await getDocs(q);
        let activeApp: StaffApplication | null = null;
        snap.forEach((doc) => {
          const data = doc.data() as StaffApplication;
          if (['Pending', 'Under Review', 'Accepted'].includes(data.status)) {
            activeApp = { ...data, id: doc.id };
          }
        });
        setExistingApp(activeApp);
      } catch (err) { console.warn('Error checking existing application:', err); }
      finally { setCheckingExisting(false); }
    }
    checkExisting();
  }, [currentUser]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!currentUser) { onOpenAuth(); return; }

    const questions = QUESTIONS[category] || QUESTIONS['Staff Application'];
    const requiredCount = questions.length;
    if (Object.keys(answers).length < requiredCount) {
      setError('Please answer all questions.');
      return;
    }

    setSubmitting(true);
    try {
      const queue: ApplicationQueue = category === 'Staff Application' ? 'Staff Review' : (category === 'Helper Application' ? 'Mod Review' : 'Admin Review');
      const newApp: Omit<StaffApplication, 'id'> = {
        applicantUid: currentUser.uid,
        applicantName: userProfile?.name || 'Unknown',
        applicantEmail: currentUser.email || '',
        discordUsername: answers['0'] || '',
        discordUserId: 'N/A', // Assuming not specifically asked for all
        age: answers['1'] || 'N/A',
        timezone: answers['2'] || 'N/A',
        availableHours: 'N/A', // Will be mapped later
        category,
        position: category,
        answers,
        status: 'Pending',
        queue,
        assignmentStatus: 'Unassigned',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      await addDoc(collection(db, 'applications'), newApp);
      setShowSuccessOverlay(true);
    } catch (err) { handleFirestoreError(err, OperationType.CREATE, 'applications'); }
    finally { setSubmitting(false); }
  };

  if (!currentUser) return (
      <div className="max-w-2xl mx-auto py-16 px-4 text-center space-y-6 bg-panel border border-secondary/20 rounded-3xl p-8 mt-10">
        <h2 className="text-2xl font-black text-main">Authentication Required</h2>
        <button onClick={onOpenAuth} className="px-8 py-3 bg-gradient-to-r from-primary to-secondary text-white font-bold text-sm rounded-xl hover:from-blue-600 hover:to-cyan-500 transition-all shadow-lg">
          Sign In / Register
        </button>
      </div>
  );

  if (checkingExisting) return <div className="max-w-2xl mx-auto py-20 text-center text-muted text-sm">Checking application history...</div>;

  if (existingApp) return (
      <div className="max-w-2xl mx-auto py-12 px-4">
        <div className="bg-panel border border-secondary/40 rounded-3xl p-8 space-y-6 text-center shadow-xl">
          <h2 className="text-2xl font-extrabold text-main">Application {existingApp.status === 'Accepted' ? 'Accepted' : 'Under Review'}</h2>
          <p className="text-sm text-muted">
            You already have an active application ({existingApp.category}) with status: <strong className="uppercase text-secondary">{existingApp.status}</strong>.
          </p>
          <button onClick={() => onNavigate('status')} className="inline-flex items-center gap-2 px-6 py-3 bg-secondary/10 hover:bg-secondary/20 text-secondary font-extrabold text-xs uppercase tracking-wider rounded-xl transition-all border border-secondary/20">
            View Status
          </button>
        </div>
      </div>
  );

  return (
    <div className="max-w-4xl mx-auto py-8 px-4 space-y-8">
      <div className="border-b border-secondary/20 pb-6">
        <h1 className="text-3xl font-black text-main uppercase tracking-tight">Apply</h1>
        <select value={category} onChange={(e) => { setCategory(e.target.value as ApplicationCategory); setAnswers({}); }} className="mt-4 bg-panel border border-secondary/20 rounded-xl px-4 py-2 text-main">
          <option value="Staff Application">Staff Application</option>
          <option value="Helper Application">Helper Application</option>
          <option value="Developer Application">Developer Application</option>
        </select>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6 bg-panel border border-secondary/20 p-8 rounded-3xl">
        {(QUESTIONS[category] || QUESTIONS['Staff Application']).map((q, i) => (
          <div key={i}>
            <label className="block text-xs font-bold text-muted mb-2 uppercase">{q}</label>
            <textarea value={answers[i.toString()] || ''} onChange={(e) => setAnswers({...answers, [i.toString()]: e.target.value})} className="w-full bg-canvas border border-secondary/20 rounded-xl p-3 text-sm text-main focus:border-secondary transition-colors" required />
          </div>
        ))}
        <button type="submit" disabled={submitting} className="w-full py-4 bg-gradient-to-r from-primary to-secondary text-white font-black rounded-2xl flex items-center justify-center gap-2 transition-all hover:opacity-90">
            {submitting ? (
                <>
                    <Loader2 className="w-5 h-5 animate-spin" /> Submitting...
                </>
            ) : 'Submit Application'}
        </button>
      </form>

      <SubmissionSuccess 
        isOpen={showSuccessOverlay} 
        onClose={() => onNavigate('status')}
        category={category}
      />
    </div>
  );
};
