import React, { useEffect, useState } from 'react';
import { collection, query, where, getDocs, updateDoc, doc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from '../context/AuthContext';
import { NotificationItem } from '../types';
import { Bell, CheckCircle2, ShieldAlert, FileText, Check } from 'lucide-react';

export const NotificationsPage: React.FC = () => {
  const { currentUser } = useAuth();
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchNotifications() {
      if (!currentUser) {
        setLoading(false);
        return;
      }
      try {
        const q = query(
          collection(db, 'notifications'),
          where('recipientUid', '==', currentUser.uid)
        );
        const snap = await getDocs(q);
        const list: NotificationItem[] = [];
        snap.forEach((d) => {
          list.push({ ...d.data(), id: d.id } as NotificationItem);
        });
        list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        setNotifications(list);
      } catch (err) {
        console.warn('Notifications fetch notice:', err);
      } finally {
        setLoading(false);
      }
    }

    fetchNotifications();
  }, [currentUser]);

  const markAsRead = async (id?: string) => {
    if (!id) return;
    try {
      await updateDoc(doc(db, 'notifications', id), { read: true });
      setNotifications((prev) =>
        prev.map((n) => (n.id === id ? { ...n, read: true } : n))
      );
    } catch (err) {
      console.warn('Error marking notification read:', err);
    }
  };

  if (!currentUser) {
    return (
      <div className="max-w-md mx-auto py-20 text-center text-zinc-400 text-sm">
        Please sign in to view notifications.
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto py-8 px-4 space-y-6">
      <div className="border-b border-zinc-800/80 pb-6">
        <span className="text-xs font-bold text-orange-400 uppercase tracking-widest">
          Updates & Inbox
        </span>
        <h1 className="text-3xl font-black text-white uppercase tracking-tight">
          Notifications
        </h1>
      </div>

      {loading ? (
        <div className="text-center py-10 text-xs text-zinc-500">Loading inbox...</div>
      ) : notifications.length === 0 ? (
        <div className="bg-zinc-950 border border-zinc-800/90 rounded-3xl p-10 text-center space-y-3">
          <Bell className="w-8 h-8 text-zinc-600 mx-auto" />
          <p className="text-xs text-zinc-400">You have no notifications right now.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {notifications.map((n) => (
            <div
              key={n.id}
              className={`p-4 rounded-2xl border transition-colors flex items-start justify-between gap-4 ${
                n.read
                  ? 'bg-zinc-950/60 border-zinc-900 text-zinc-400'
                  : 'bg-zinc-900 border-orange-900/40 text-white shadow-lg'
              }`}
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-zinc-200">{n.title}</span>
                  {!n.read && (
                    <span className="w-2 h-2 rounded-full bg-orange-500 animate-pulse" />
                  )}
                </div>
                <p className="text-xs leading-relaxed">{n.message}</p>
                <span className="text-[10px] text-zinc-500 block pt-1">
                  {new Date(n.createdAt).toLocaleString()}
                </span>
              </div>

              {!n.read && (
                <button
                  onClick={() => markAsRead(n.id)}
                  className="p-2 text-xs text-orange-400 hover:text-white hover:bg-zinc-800 rounded-xl transition-colors"
                  title="Mark as Read"
                >
                  <Check className="w-4 h-4" />
                </button>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
