import React, { useEffect, useState } from 'react';
import { collection, query, where, getDocs, doc, updateDoc, setDoc, addDoc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../../lib/firebase';
import { useAuth } from '../../context/AuthContext';
import { logAuditEvent } from '../../lib/auditLogger';
import { UserProfile, UserRole, StaffApplication, UserReport, AuditLogEntry } from '../../types';
import { X, User, Shield, Mail, Calendar, Key, AlertTriangle, FileText, CheckCircle2, Lock, Clock, History, AlertCircle, Award } from 'lucide-react';

interface UserProfileDetailModalProps {
  user: UserProfile;
  isOpen: boolean;
  onClose: () => void;
  onProfileUpdated: () => void;
}

export const UserProfileDetailModal: React.FC<UserProfileDetailModalProps> = ({
  user,
  isOpen,
  onClose,
  onProfileUpdated,
}) => {
  const { currentUser, userProfile: currentUserProfile } = useAuth();

  const [activeTab, setActiveTab] = useState<'account' | 'applications' | 'role' | 'moderation' | 'activity'>('account');

  // Related User Data Fetched On-Demand
  const [userApps, setUserApps] = useState<StaffApplication[]>([]);
  const [userReports, setUserReports] = useState<UserReport[]>([]);
  const [userAuditLogs, setUserAuditLogs] = useState<AuditLogEntry[]>([]);
  const [loadingData, setLoadingData] = useState(true);

  // Role Management State
  const [selectedRole, setSelectedRole] = useState<UserRole>(user.role);
  const [updatingRole, setUpdatingRole] = useState(false);

  // Suspension State
  const [suspensionReason, setSuspensionReason] = useState(user.suspensionReason || '');
  const [updatingSuspension, setUpdatingSuspension] = useState(false);

  useEffect(() => {
    setSelectedRole(user.role);
    setSuspensionReason(user.suspensionReason || '');
  }, [user]);

  // ON-DEMAND DATA FETCHING (Only loads data for THIS specific user when modal opens!)
  useEffect(() => {
    async function loadTargetUserData() {
      if (!isOpen || !user.uid) return;
      setLoadingData(true);

      try {
        const [appsSnap, reportsSnap, logsSnap] = await Promise.all([
          getDocs(query(collection(db, 'applications'), where('applicantUid', '==', user.uid))),
          getDocs(query(collection(db, 'reports'), where('authorUid', '==', user.uid))),
          getDocs(query(collection(db, 'audit_logs'), where('targetUid', '==', user.uid))),
        ]);

        const appsList: StaffApplication[] = [];
        appsSnap.forEach((d) => appsList.push({ ...d.data(), id: d.id } as StaffApplication));
        appsList.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        setUserApps(appsList);

        const reportsList: UserReport[] = [];
        reportsSnap.forEach((d) => reportsList.push({ ...d.data(), id: d.id } as UserReport));
        reportsList.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        setUserReports(reportsList);

        const logsList: AuditLogEntry[] = [];
        logsSnap.forEach((d) => logsList.push({ ...d.data(), id: d.id } as AuditLogEntry));
        logsList.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
        setUserAuditLogs(logsList);
      } catch (err) {
        console.warn('Error loading detailed profile data:', err);
      } finally {
        setLoadingData(false);
      }
    }

    loadTargetUserData();
  }, [isOpen, user.uid]);

  if (!isOpen) return null;

  // Role Assignment
  const handleAssignRole = async () => {
    if (!currentUser || selectedRole === user.role) return;
    setUpdatingRole(true);

    try {
      const userRef = doc(db, 'users', user.uid);
      const updates = {
        role: selectedRole,
        roleAssignedAt: new Date().toISOString(),
        roleAssignedBy: currentUserProfile?.name || currentUser.email || 'Owner',
      };

      await updateDoc(userRef, updates);

      // Create Notification
      await addDoc(collection(db, 'notifications'), {
        recipientUid: user.uid,
        title: `Role Updated: ${selectedRole}`,
        message: `Your account role has been updated to ${selectedRole} by Owner.`,
        type: 'role',
        read: false,
        createdAt: new Date().toISOString(),
      });

      // Audit Log
      await logAuditEvent({
        action: 'OWNER_ROLE_UPDATED',
        actorUid: currentUser.uid,
        actorName: currentUserProfile?.name || 'Owner',
        actorEmail: currentUser.email || '',
        actorRole: 'OWNER',
        targetResource: 'users',
        targetUid: user.uid,
        metadata: { previousRole: user.role, newRole: selectedRole },
      });

      onProfileUpdated();
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${user.uid}`);
    } finally {
      setUpdatingRole(false);
    }
  };

  // Toggle Suspension
  const handleToggleSuspension = async () => {
    if (!currentUser) return;
    setUpdatingSuspension(true);
    const nextState = !user.isSuspended;

    try {
      const userRef = doc(db, 'users', user.uid);
      const updates = {
        isSuspended: nextState,
        suspensionReason: nextState ? suspensionReason.trim() || 'Rule violation' : '',
        suspensionDate: nextState ? new Date().toISOString() : '',
        suspendedBy: nextState ? currentUserProfile?.name || 'Owner' : '',
      };

      await updateDoc(userRef, updates);

      await logAuditEvent({
        action: nextState ? 'USER_SUSPENDED' : 'USER_ACTIVATED',
        actorUid: currentUser.uid,
        actorName: currentUserProfile?.name || 'Owner',
        actorEmail: currentUser.email || '',
        actorRole: 'OWNER',
        targetResource: 'users',
        targetUid: user.uid,
        metadata: { isSuspended: nextState, reason: suspensionReason },
      });

      onProfileUpdated();
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${user.uid}`);
    } finally {
      setUpdatingSuspension(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-zinc-950 border border-zinc-800 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 max-h-[90vh] overflow-y-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-6 right-6 p-2 text-zinc-400 hover:text-white hover:bg-zinc-900 rounded-xl transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header Profile Summary */}
        <div className="flex flex-col sm:flex-row items-center sm:items-start gap-5 border-b border-zinc-900 pb-6">
          <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center font-black text-3xl text-black shadow-lg">
            {user.name?.charAt(0).toUpperCase() || 'U'}
          </div>
          <div className="text-center sm:text-left space-y-1">
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
              <h2 className="text-2xl font-black text-white">{user.name}</h2>
              <span className="text-xs font-black px-3 py-1 rounded-full bg-amber-950 text-amber-400 border border-amber-800 uppercase">
                {user.role}
              </span>
              {user.isSuspended && (
                <span className="text-xs font-bold px-3 py-1 rounded-full bg-red-950 text-red-400 border border-red-800 uppercase">
                  SUSPENDED
                </span>
              )}
            </div>
            <p className="text-xs text-zinc-400">{user.email}</p>
            <p className="text-[10px] font-mono text-zinc-500">UID: {user.uid}</p>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex flex-wrap items-center gap-2 border-b border-zinc-900 pb-3 text-xs font-bold">
          <button
            onClick={() => setActiveTab('account')}
            className={`px-3.5 py-1.5 rounded-xl transition-all ${
              activeTab === 'account' ? 'bg-amber-500 text-black shadow-md' : 'text-zinc-400 hover:text-white'
            }`}
          >
            Account Details
          </button>
          <button
            onClick={() => setActiveTab('applications')}
            className={`px-3.5 py-1.5 rounded-xl transition-all ${
              activeTab === 'applications' ? 'bg-amber-500 text-black shadow-md' : 'text-zinc-400 hover:text-white'
            }`}
          >
            Applications ({userApps.length})
          </button>
          <button
            onClick={() => setActiveTab('role')}
            className={`px-3.5 py-1.5 rounded-xl transition-all ${
              activeTab === 'role' ? 'bg-amber-500 text-black shadow-md' : 'text-zinc-400 hover:text-white'
            }`}
          >
            Role & Permissions
          </button>
          <button
            onClick={() => setActiveTab('moderation')}
            className={`px-3.5 py-1.5 rounded-xl transition-all ${
              activeTab === 'moderation' ? 'bg-amber-500 text-black shadow-md' : 'text-zinc-400 hover:text-white'
            }`}
          >
            Moderation ({userReports.length})
          </button>
          <button
            onClick={() => setActiveTab('activity')}
            className={`px-3.5 py-1.5 rounded-xl transition-all ${
              activeTab === 'activity' ? 'bg-amber-500 text-black shadow-md' : 'text-zinc-400 hover:text-white'
            }`}
          >
            Audit History ({userAuditLogs.length})
          </button>
        </div>

        {/* TAB 1: ACCOUNT DETAILS */}
        {activeTab === 'account' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div className="bg-zinc-900/60 p-4 rounded-2xl border border-zinc-800 space-y-1">
              <span className="text-zinc-500 uppercase font-bold text-[10px] block">User ID (UID)</span>
              <span className="font-mono text-zinc-200 font-bold break-all">{user.uid}</span>
            </div>

            <div className="bg-zinc-900/60 p-4 rounded-2xl border border-zinc-800 space-y-1">
              <span className="text-zinc-500 uppercase font-bold text-[10px] block">Email Address</span>
              <span className="text-zinc-200 font-bold">{user.email}</span>
            </div>

            <div className="bg-zinc-900/60 p-4 rounded-2xl border border-zinc-800 space-y-1">
              <span className="text-zinc-500 uppercase font-bold text-[10px] block">Account Creation Date</span>
              <span className="text-zinc-200 font-bold">{new Date(user.createdAt || Date.now()).toLocaleString()}</span>
            </div>

            <div className="bg-zinc-900/60 p-4 rounded-2xl border border-zinc-800 space-y-1">
              <span className="text-zinc-500 uppercase font-bold text-[10px] block">Auth Provider</span>
              <span className="text-zinc-200 font-bold uppercase">{user.providerId || 'Email / Password'}</span>
            </div>

            <div className="bg-zinc-900/60 p-4 rounded-2xl border border-zinc-800 space-y-1">
              <span className="text-zinc-500 uppercase font-bold text-[10px] block">Current Role</span>
              <span className="text-amber-400 font-extrabold uppercase">{user.role}</span>
            </div>

            <div className="bg-zinc-900/60 p-4 rounded-2xl border border-zinc-800 space-y-1">
              <span className="text-zinc-500 uppercase font-bold text-[10px] block">Account Status</span>
              <span className={user.isSuspended ? 'text-red-400 font-bold' : 'text-emerald-400 font-bold'}>
                {user.isSuspended ? 'Suspended' : 'Active'}
              </span>
            </div>
          </div>
        )}

        {/* TAB 2: APPLICATION HISTORY */}
        {activeTab === 'applications' && (
          <div className="space-y-3 text-xs">
            {loadingData ? (
              <div className="text-center py-6 text-zinc-500">Loading user application history...</div>
            ) : userApps.length === 0 ? (
              <div className="p-8 text-center bg-zinc-900/40 rounded-2xl border border-zinc-800 text-zinc-500">
                No data available. This user has not submitted any staff applications yet.
              </div>
            ) : (
              userApps.map((app) => (
                <div key={app.id} className="p-4 bg-zinc-900/80 rounded-2xl border border-zinc-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-extrabold text-white">Position: {app.position}</span>
                    <span className="px-2.5 py-0.5 rounded-full font-bold bg-zinc-800 text-amber-400 uppercase text-[10px]">
                      {app.status}
                    </span>
                  </div>
                  <div className="text-[11px] text-zinc-400">
                    App ID: <span className="font-mono text-zinc-300">{app.id}</span> • Submitted: {new Date(app.createdAt).toLocaleDateString()}
                  </div>
                  {app.reviewNotes && (
                    <div className="p-2.5 bg-zinc-950 rounded-xl text-amber-200/90 italic">
                      "Reviewer Note ({app.reviewerRole || 'Staff'}): {app.reviewNotes}"
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        )}

        {/* TAB 3: ROLE MANAGEMENT */}
        {activeTab === 'role' && (
          <div className="space-y-6 text-xs bg-zinc-900/60 p-6 rounded-2xl border border-zinc-800">
            <h3 className="text-sm font-extrabold text-white uppercase tracking-wider">
              Manage Role & Hierarchy Level
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-bold text-zinc-400 mb-1.5 uppercase tracking-wider text-[10px]">
                  Select New Role
                </label>
                <select
                  value={selectedRole}
                  onChange={(e) => setSelectedRole(e.target.value as UserRole)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl py-2.5 px-3 font-bold text-amber-400 outline-none"
                >
                  <option value="USER">USER</option>
                  <option value="STAFF">STAFF</option>
                  <option value="MOD">MOD</option>
                  <option value="ADMIN">ADMIN</option>
                  <option value="OWNER">OWNER</option>
                </select>
              </div>

              <div className="flex items-end">
                <button
                  onClick={handleAssignRole}
                  disabled={updatingRole || selectedRole === user.role}
                  className="w-full py-2.5 bg-amber-500 hover:bg-amber-400 text-black font-extrabold uppercase tracking-wider rounded-xl transition-all shadow-md disabled:opacity-50"
                >
                  {updatingRole ? 'Assigning...' : 'Confirm Role Change'}
                </button>
              </div>
            </div>

            {user.roleAssignedBy && (
              <div className="p-3 bg-zinc-950 rounded-xl text-[11px] text-zinc-400">
                Last Role Update: <strong className="text-zinc-200">{new Date(user.roleAssignedAt || Date.now()).toLocaleDateString()}</strong> by <strong className="text-amber-400">{user.roleAssignedBy}</strong>
              </div>
            )}
          </div>
        )}

        {/* TAB 4: MODERATION & SUSPENSION */}
        {activeTab === 'moderation' && (
          <div className="space-y-6 text-xs">
            <div className="bg-zinc-900/60 p-6 rounded-2xl border border-zinc-800 space-y-4">
              <h3 className="text-sm font-extrabold text-white uppercase tracking-wider">
                Account Suspension Control
              </h3>

              <div>
                <label className="block font-bold text-zinc-400 mb-1.5 uppercase tracking-wider text-[10px]">
                  Suspension Reason / Internal Note
                </label>
                <input
                  type="text"
                  value={suspensionReason}
                  onChange={(e) => setSuspensionReason(e.target.value)}
                  placeholder="Specify violation or reason for suspension..."
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl py-2.5 px-3 text-white outline-none"
                />
              </div>

              <button
                onClick={handleToggleSuspension}
                disabled={updatingSuspension}
                className={`w-full py-3 font-extrabold uppercase tracking-wider rounded-xl transition-all ${
                  user.isSuspended
                    ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                    : 'bg-red-600 hover:bg-red-500 text-white shadow-lg shadow-red-950/40'
                }`}
              >
                {user.isSuspended ? 'Activate User Account' : 'Suspend User Account'}
              </button>

              {user.isSuspended && user.suspensionDate && (
                <div className="p-3 bg-red-950/60 border border-red-800/60 rounded-xl text-red-200 text-xs">
                  <strong>Suspended On:</strong> {new Date(user.suspensionDate).toLocaleDateString()} by {user.suspendedBy || 'Moderation'}
                  <br />
                  <strong>Reason:</strong> {user.suspensionReason || 'None specified.'}
                </div>
              )}
            </div>

            {/* Reports Submitted */}
            <div className="space-y-2">
              <h4 className="font-extrabold text-zinc-300 uppercase tracking-wider text-xs">
                Submitted Incident Reports ({userReports.length})
              </h4>
              {userReports.length === 0 ? (
                <div className="p-4 bg-zinc-900/40 rounded-xl text-zinc-500 text-center">
                  No data available.
                </div>
              ) : (
                userReports.map((r) => (
                  <div key={r.id} className="p-3 bg-zinc-900 rounded-xl border border-zinc-800 flex items-center justify-between">
                    <div>
                      <span className="font-bold text-white">{r.subject}</span>
                      <span className="text-zinc-400 block text-[10px]">{r.reportType}</span>
                    </div>
                    <span className="font-bold text-amber-400 uppercase text-[10px]">{r.status}</span>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* TAB 5: AUDIT LOGS */}
        {activeTab === 'activity' && (
          <div className="space-y-2 text-xs">
            {loadingData ? (
              <div className="text-center py-6 text-zinc-500">Loading audit history...</div>
            ) : userAuditLogs.length === 0 ? (
              <div className="p-8 text-center bg-zinc-900/40 rounded-2xl border border-zinc-800 text-zinc-500">
                No data available. No security or administrative audit records found for this user target.
              </div>
            ) : (
              userAuditLogs.map((log) => (
                <div key={log.id} className="p-3 bg-zinc-900/80 rounded-xl border border-zinc-800 flex items-center justify-between">
                  <div>
                    <span className="font-extrabold text-white">{log.actorName}</span>{' '}
                    <span className="text-zinc-500">({log.actorRole}):</span>{' '}
                    <span className="text-amber-400 font-bold">{log.action}</span>
                  </div>
                  <span className="text-zinc-500 text-[10px]">{new Date(log.timestamp).toLocaleString()}</span>
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
};
