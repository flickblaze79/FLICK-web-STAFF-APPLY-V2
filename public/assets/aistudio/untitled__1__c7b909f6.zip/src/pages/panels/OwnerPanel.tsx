import React, { useEffect, useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { collection, getDocs, doc, updateDoc, setDoc, addDoc, limit, query } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../../lib/firebase';
import { useAuth } from '../../context/AuthContext';
import { logAuditEvent } from '../../lib/auditLogger';
import { StaffApplication, UserProfile, UserRole, UserReport, AuditLogEntry, QUESTIONS } from '../../types';
import { UserProfileDetailModal } from './UserProfileDetailModal';
import { ApplicationActionAnimation } from '../../components/ApplicationActionAnimation';
import {
  Crown,
  Users,
  FileText,
  Settings,
  Search,
  Activity,
  Award,
  ChevronLeft,
  ChevronRight,
  Eye,
  AlertCircle,
} from 'lucide-react';

export const OwnerPanel: React.FC = () => {
  const { currentUser, userProfile: currentUserProfile, isOwner } = useAuth();

  const [activeTab, setActiveTab] = useState<'dashboard' | 'users' | 'applications' | 'reports' | 'security' | 'settings'>('dashboard');

  // Core Datasets
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [applications, setApplications] = useState<StaffApplication[]>([]);
  const [reports, setReports] = useState<UserReport[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>([]);
  const [loading, setLoading] = useState(true);

  // Selected User for Detailed Profile Modal
  const [inspectUser, setSelectedInspectUser] = useState<UserProfile | null>(null);

  // Search & Filtering for Users
  const [userSearch, setUserSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState<string>('All');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [userPage, setUserPage] = useState(1);
  const USERS_PER_PAGE = 8;

  // Search & Filtering for Applications
  const [appSearch, setAppSearch] = useState('');
  const [appStatusFilter, setAppStatusFilter] = useState<string>('All');
  const [appQueueFilter, setAppQueueFilter] = useState<string>('All');
  const [appSort, setAppSort] = useState<'newest' | 'oldest'>('newest');
  const [appPage, setAppPage] = useState(1);
  const APPS_PER_PAGE = 6;

  // Review & Decision state
  const [selectedApp, setSelectedApp] = useState<StaffApplication | null>(null);
  const [reviewNote, setReviewNote] = useState('');
  const [reviewerAssignmentUid, setReviewerAssignmentUid] = useState('');
  const [processingId, setProcessingId] = useState<string | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);

  // Decision Animation State
  const [animatingDecision, setAnimatingDecision] = useState<{ id: string; status: 'Accepted' | 'Rejected'; name: string; position: string } | null>(null);

  // Global Settings State
  const [announcementText, setAnnouncementText] = useState('FLICK Staff Applications are currently OPEN.');
  const [appsOpen, setAppsOpen] = useState(true);
  const [requirementsText, setRequirementsText] = useState('Min. Age: 14+, Active on Discord, Clean disciplinary history.');

  // Fetch initial datasets
  const loadOwnerData = async () => {
    try {
      const [usersSnap, appsSnap, reportsSnap, logsSnap] = await Promise.all([
        getDocs(collection(db, 'users')),
        getDocs(collection(db, 'applications')),
        getDocs(collection(db, 'reports')),
        getDocs(query(collection(db, 'audit_logs'), limit(100))),
      ]);

      const uList: UserProfile[] = [];
      usersSnap.forEach((d) => {
        const data = d.data();
        uList.push({ ...data, uid: d.id } as UserProfile);
      });
      setUsers(uList);

      const aList: StaffApplication[] = [];
      appsSnap.forEach((d) => {
        const data = d.data();
        aList.push({ ...data, id: d.id } as StaffApplication);
      });
      setApplications(aList);

      const rList: UserReport[] = [];
      reportsSnap.forEach((d) => {
        const data = d.data();
        rList.push({ ...data, id: d.id } as UserReport);
      });
      rList.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      setReports(rList);

      const lList: AuditLogEntry[] = [];
      logsSnap.forEach((d) => {
        const data = d.data();
        lList.push({ ...data, id: d.id } as AuditLogEntry);
      });
      lList.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
      setAuditLogs(lList);
    } catch (err) {
      console.error('Error loading Owner Panel data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOwner) {
      loadOwnerData();
    }
  }, [isOwner]);

  if (!isOwner) {
    return (
      <div className="max-w-md mx-auto py-20 text-center text-red-400 font-bold text-sm bg-zinc-950 border border-red-900/50 rounded-2xl p-8 mt-10">
        Access Denied: Only the verified Owner can access this panel.
      </div>
    );
  }

  // Dashboard Aggregations
  const totalUsersCount = users.length;
  const newUsersCount = users.filter((u) => {
    const created = new Date(u.createdAt || Date.now()).getTime();
    const sevenDaysAgo = Date.now() - 7 * 24 * 60 * 60 * 1000;
    return created >= sevenDaysAgo;
  }).length;

  const totalAppsCount = applications.length;
  const pendingAppsCount = applications.filter((a) => a.status === 'Pending').length;
  const reviewAppsCount = applications.filter((a) => a.status === 'Under Review').length;
  const acceptedAppsCount = applications.filter((a) => a.status === 'Accepted').length;
  const rejectedAppsCount = applications.filter((a) => a.status === 'Rejected').length;

  const staffCount = users.filter((u) => u.role === 'STAFF').length;
  const modCount = users.filter((u) => u.role === 'MOD').length;
  const adminCount = users.filter((u) => u.role === 'ADMIN').length;
  const suspendedUsersCount = users.filter((u) => u.isSuspended).length;
  const activeUsersCount = totalUsersCount - suspendedUsersCount;

  // Filtered Users
  const filteredUsers = useMemo(() => {
    return users.filter((u) => {
      const matchSearch =
        u.name.toLowerCase().includes(userSearch.toLowerCase()) ||
        u.email.toLowerCase().includes(userSearch.toLowerCase()) ||
        u.uid.toLowerCase().includes(userSearch.toLowerCase());
      const matchRole = roleFilter === 'All' || u.role === roleFilter;
      const matchStatus =
        statusFilter === 'All'
          ? true
          : statusFilter === 'Active'
          ? !u.isSuspended
          : u.isSuspended;
      return matchSearch && matchRole && matchStatus;
    });
  }, [users, userSearch, roleFilter, statusFilter]);

  const totalUserPages = Math.ceil(filteredUsers.length / USERS_PER_PAGE) || 1;
  const paginatedUsers = useMemo(() => {
    const start = (userPage - 1) * USERS_PER_PAGE;
    return filteredUsers.slice(start, start + USERS_PER_PAGE);
  }, [filteredUsers, userPage]);

  // Filtered Applications
  const filteredApps = useMemo(() => {
    let list = applications.filter((app) => {
      // REJECTED APPLICATION VISIBILITY RULE: Once rejected, an application must NEVER appear in any staff/mod/admin/owner list or filter
      if (app.status === 'Rejected') return false;
      const matchSearch =
        app.applicantName.toLowerCase().includes(appSearch.toLowerCase()) ||
        app.applicantEmail.toLowerCase().includes(appSearch.toLowerCase()) ||
        app.discordUsername.toLowerCase().includes(appSearch.toLowerCase()) ||
        app.position.toLowerCase().includes(appSearch.toLowerCase());
      const matchStatus = appStatusFilter === 'All' || app.status === appStatusFilter;
      const matchQueue = appQueueFilter === 'All' || app.queue === appQueueFilter;
      return matchSearch && matchStatus && matchQueue;
    });

    list.sort((a, b) => {
      const timeA = new Date(a.createdAt).getTime();
      const timeB = new Date(b.createdAt).getTime();
      return appSort === 'newest' ? timeB - timeA : timeA - timeB;
    });

    return list;
  }, [applications, appSearch, appStatusFilter, appQueueFilter, appSort]);

  const totalAppPages = Math.ceil(filteredApps.length / APPS_PER_PAGE) || 1;
  const paginatedApps = useMemo(() => {
    const start = (appPage - 1) * APPS_PER_PAGE;
    return filteredApps.slice(start, start + APPS_PER_PAGE);
  }, [filteredApps, appPage]);

  // OWNER APPLICATION DECISION WITH ANIMATION & REAL NOTIFICATION
  const handleOwnerDecision = async (appId: string, status: 'Accepted' | 'Rejected' | 'Under Review') => {
    if (!currentUser || processingId === appId) return;
    const app = applications.find((a) => a.id === appId);
    if (!app) return;

    setActionError(null);
    setProcessingId(appId);

    try {
      const appRef = doc(db, 'applications', appId);
      const updates = {
        status,
        reviewerUid: currentUser.uid,
        reviewerRole: 'OWNER' as UserRole,
        reviewNotes: reviewNote.trim() || app.reviewNotes || '',
        updatedAt: new Date().toISOString(),
      };

      // 1. UPDATE FIRESTORE
      await updateDoc(appRef, updates);

      // 2. REAL FIREBASE NOTIFICATION FOR APPLICANT
      let notifMessage = `Your staff application for ${app.position} status was changed to ${status} by Owner.`;
      if (status === 'Accepted') {
        notifMessage = `Your Staff Application has been Accepted. Role: ${app.position}`;
      } else if (status === 'Rejected') {
        notifMessage = `Your Staff Application has been Rejected.`;
      }

      await addDoc(collection(db, 'notifications'), {
        recipientUid: app.applicantUid,
        title: `Owner Decision: ${status}`,
        message: notifMessage,
        type: 'application',
        read: false,
        createdAt: new Date().toISOString(),
      });

      // 3. AUDIT LOG
      await logAuditEvent({
        action: `OWNER_DECISION_${status.toUpperCase().replace(' ', '_')}`,
        actorUid: currentUser.uid,
        actorName: currentUserProfile?.name || 'Owner',
        actorEmail: currentUser.email || '',
        actorRole: 'OWNER',
        targetResource: 'applications',
        targetUid: appId,
        metadata: { position: app.position, status },
      });

      setApplications((prev) =>
        prev.map((a) => (a.id === appId ? { ...a, ...updates } : a))
      );

      // 4. ANIMATION OVERLAY IF ACCEPTED OR REJECTED
      if (status === 'Accepted' || status === 'Rejected') {
        setAnimatingDecision({ id: appId, status, name: app.applicantName, position: app.position });
        setTimeout(() => {
          setAnimatingDecision(null);
        }, 1300);
      }
    } catch (err: any) {
      console.error('Owner Decision Error:', err);
      setActionError(err?.message || 'Failed to update decision in Firebase.');
    } finally {
      setProcessingId(null);
    }
  };

  // Assign Reviewer to Application
  const handleAssignReviewer = async (appId: string) => {
    if (!currentUser || !reviewerAssignmentUid) return;
    const app = applications.find((a) => a.id === appId);
    const assignedUser = users.find((u) => u.uid === reviewerAssignmentUid);
    if (!app || !assignedUser) return;

    try {
      const ref = doc(db, 'applications', appId);
      const updates = {
        assignedReviewerUid: assignedUser.uid,
        assignedReviewerName: assignedUser.name,
        assignmentStatus: 'Assigned' as const,
        assignedAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      await updateDoc(ref, updates);

      await logAuditEvent({
        action: 'OWNER_APPLICATION_ASSIGNED',
        actorUid: currentUser.uid,
        actorName: currentUserProfile?.name || 'Owner',
        actorEmail: currentUser.email || '',
        actorRole: 'OWNER',
        targetResource: 'applications',
        targetUid: appId,
        metadata: { assignedToUid: assignedUser.uid, assignedToName: assignedUser.name },
      });

      setApplications((prev) =>
        prev.map((a) => (a.id === appId ? { ...a, ...updates } : a))
      );
      setReviewerAssignmentUid('');
      alert(`Application successfully assigned to ${assignedUser.name}!`);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `applications/${appId}`);
    }
  };

  // Save Settings
  const handleSaveSettings = async () => {
    if (!currentUser) return;
    try {
      await setDoc(
        doc(db, 'system_settings', 'global'),
        {
          applicationsOpen: appsOpen,
          announcementText,
          requirementsText,
          updatedAt: new Date().toISOString(),
        },
        { merge: true }
      );

      await logAuditEvent({
        action: 'OWNER_SETTINGS_SAVED',
        actorUid: currentUser.uid,
        actorName: currentUserProfile?.name || 'Owner',
        actorEmail: currentUser.email || '',
        actorRole: 'OWNER',
        targetResource: 'system_settings',
      });

      alert('Global System Settings Saved!');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'system_settings/global');
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="max-w-7xl mx-auto py-8 px-4 space-y-8"
    >
      {/* Header */}
      <div className="border-b border-zinc-800/80 pb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-black text-amber-400 uppercase tracking-widest">
            <Crown className="w-4 h-4 text-amber-400" />
            <span>Supreme Ownership Command</span>
          </div>
          <h1 className="text-3xl font-black text-white uppercase tracking-tight mt-1">
            Owner Panel
          </h1>
          <p className="text-xs text-zinc-400">
            Real-time server telemetry, user management, application queues, security audit feeds, and settings.
          </p>
        </div>

        {/* Tab Navigation */}
        <div className="flex flex-wrap items-center gap-1 bg-zinc-900 p-1.5 rounded-2xl border border-zinc-800">
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'dashboard' ? 'bg-amber-500 text-black shadow-md' : 'text-zinc-400 hover:text-white'
            }`}
          >
            Dashboard
          </button>
          <button
            onClick={() => setActiveTab('users')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'users' ? 'bg-amber-500 text-black shadow-md' : 'text-zinc-400 hover:text-white'
            }`}
          >
            Users ({totalUsersCount})
          </button>
          <button
            onClick={() => setActiveTab('applications')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'applications' ? 'bg-amber-500 text-black shadow-md' : 'text-zinc-400 hover:text-white'
            }`}
          >
            Applications ({totalAppsCount})
          </button>
          <button
            onClick={() => setActiveTab('reports')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'reports' ? 'bg-amber-500 text-black shadow-md' : 'text-zinc-400 hover:text-white'
            }`}
          >
            Reports ({reports.length})
          </button>
          <button
            onClick={() => setActiveTab('security')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'security' ? 'bg-amber-500 text-black shadow-md' : 'text-zinc-400 hover:text-white'
            }`}
          >
            Security Vault
          </button>
          <button
            onClick={() => setActiveTab('settings')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'settings' ? 'bg-amber-500 text-black shadow-md' : 'text-zinc-400 hover:text-white'
            }`}
          >
            Settings
          </button>
        </div>
      </div>

      {actionError && (
        <div className="p-3 bg-red-950/80 border border-red-800 rounded-xl text-red-200 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
          <span>{actionError}</span>
        </div>
      )}

      {/* 1. DASHBOARD TAB */}
      {activeTab === 'dashboard' && (
        <div className="space-y-8">
          {/* Real Metrics Grid */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <motion.div whileHover={{ y: -3 }} className="bg-zinc-950 border border-zinc-800 p-5 rounded-3xl space-y-2">
              <div className="text-xs font-bold text-zinc-400 uppercase tracking-wider flex items-center justify-between">
                <span>Total Registered Users</span>
                <Users className="w-4 h-4 text-amber-400" />
              </div>
              <div className="text-3xl font-black text-white">{totalUsersCount}</div>
              <div className="text-[10px] font-bold text-emerald-400">{newUsersCount} new in past 7 days</div>
            </motion.div>

            <motion.div whileHover={{ y: -3 }} className="bg-zinc-950 border border-zinc-800 p-5 rounded-3xl space-y-2">
              <div className="text-xs font-bold text-zinc-400 uppercase tracking-wider flex items-center justify-between">
                <span>Total Applications</span>
                <FileText className="w-4 h-4 text-orange-400" />
              </div>
              <div className="text-3xl font-black text-white">{totalAppsCount}</div>
              <div className="text-[10px] text-zinc-400 font-semibold">{pendingAppsCount} Pending • {reviewAppsCount} Reviewing</div>
            </motion.div>

            <motion.div whileHover={{ y: -3 }} className="bg-zinc-950 border border-zinc-800 p-5 rounded-3xl space-y-2">
              <div className="text-xs font-bold text-zinc-400 uppercase tracking-wider flex items-center justify-between">
                <span>Accepted / Rejected</span>
                <Award className="w-4 h-4 text-emerald-400" />
              </div>
              <div className="text-3xl font-black text-emerald-400">{acceptedAppsCount} <span className="text-zinc-500 font-normal text-xl">/ {rejectedAppsCount}</span></div>
              <div className="text-[10px] text-zinc-400 font-semibold">Accepted staff & candidates</div>
            </motion.div>

            <motion.div whileHover={{ y: -3 }} className="bg-zinc-950 border border-zinc-800 p-5 rounded-3xl space-y-2">
              <div className="text-xs font-bold text-zinc-400 uppercase tracking-wider flex items-center justify-between">
                <span>Staff Hierarchy</span>
                <Crown className="w-4 h-4 text-amber-400" />
              </div>
              <div className="text-xl font-extrabold text-white">
                {staffCount} <span className="text-xs text-zinc-500">Staff</span> • {modCount} <span className="text-xs text-zinc-500">Mods</span> • {adminCount} <span className="text-xs text-zinc-500">Admins</span>
              </div>
              <div className="text-[10px] text-zinc-400 font-semibold">{activeUsersCount} Active • {suspendedUsersCount} Suspended</div>
            </motion.div>
          </div>

          {/* Audit Activity Stream */}
          <div className="bg-zinc-950 border border-zinc-800/90 rounded-3xl p-6 space-y-4">
            <h3 className="text-xs font-extrabold text-white uppercase tracking-wider flex items-center gap-2">
              <Activity className="w-4 h-4 text-amber-400" />
              <span>Real-Time Audit Activity Feed</span>
            </h3>
            {auditLogs.length === 0 ? (
              <div className="text-xs text-zinc-500 py-4 text-center">No activity available.</div>
            ) : (
              <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
                {auditLogs.slice(0, 15).map((log) => (
                  <div key={log.id} className="p-3 bg-zinc-900/60 rounded-2xl border border-zinc-800 text-xs flex items-center justify-between">
                    <div>
                      <span className="font-extrabold text-white">{log.actorName}</span>{' '}
                      <span className="text-zinc-500">({log.actorRole}):</span>{' '}
                      <span className="text-amber-400 font-bold">{log.action}</span>
                    </div>
                    <span className="text-[10px] text-zinc-500">{new Date(log.timestamp).toLocaleString()}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* 2. USER MANAGEMENT TAB */}
      {activeTab === 'users' && (
        <div className="space-y-6">
          {/* Controls Bar */}
          <div className="bg-zinc-950 border border-zinc-800/90 rounded-3xl p-5 space-y-4">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="relative w-full sm:w-1/2">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
                <input
                  type="text"
                  value={userSearch}
                  onChange={(e) => {
                    setUserSearch(e.target.value);
                    setUserPage(1);
                  }}
                  placeholder="Search user by name, email, or UID..."
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-2xl py-2.5 pl-11 pr-4 text-xs text-white outline-none focus:border-amber-500"
                />
              </div>

              <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto">
                <div className="flex items-center gap-1.5 text-xs">
                  <span className="text-zinc-400 font-semibold">Role:</span>
                  <select
                    value={roleFilter}
                    onChange={(e) => {
                      setRoleFilter(e.target.value);
                      setUserPage(1);
                    }}
                    className="bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-1.5 text-xs text-white outline-none"
                  >
                    <option value="All">All Roles</option>
                    <option value="USER">USER</option>
                    <option value="STAFF">STAFF</option>
                    <option value="MOD">MOD</option>
                    <option value="ADMIN">ADMIN</option>
                    <option value="OWNER">OWNER</option>
                  </select>
                </div>

                <div className="flex items-center gap-1.5 text-xs">
                  <span className="text-zinc-400 font-semibold">Status:</span>
                  <select
                    value={statusFilter}
                    onChange={(e) => {
                      setStatusFilter(e.target.value);
                      setUserPage(1);
                    }}
                    className="bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-1.5 text-xs text-white outline-none"
                  >
                    <option value="All">All Statuses</option>
                    <option value="Active">Active</option>
                    <option value="Suspended">Suspended</option>
                  </select>
                </div>
              </div>
            </div>
          </div>

          {/* Users Table / List */}
          {paginatedUsers.length === 0 ? (
            <div className="bg-zinc-950 border border-zinc-800/90 rounded-3xl p-12 text-center text-xs text-zinc-500">
              No users found matching query filters.
            </div>
          ) : (
            <div className="space-y-3">
              {paginatedUsers.map((u) => (
                <div
                  key={u.uid}
                  className="bg-zinc-950 border border-zinc-800/90 rounded-2xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:border-zinc-700 transition-colors"
                >
                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-sm font-extrabold text-white">{u.name}</span>
                      <span className="text-[10px] font-mono text-zinc-500">({u.uid})</span>
                      <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-zinc-900 text-amber-400 border border-zinc-800 uppercase">
                        {u.role}
                      </span>
                      {u.isSuspended && (
                        <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-red-950 text-red-400 border border-red-800 uppercase">
                          SUSPENDED
                        </span>
                      )}
                    </div>
                    <div className="text-xs text-zinc-400">
                      {u.email} • Registered: {new Date(u.createdAt || Date.now()).toLocaleDateString()}
                    </div>
                  </div>

                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => setSelectedInspectUser(u)}
                    className="inline-flex items-center justify-center gap-2 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-black font-extrabold text-xs uppercase tracking-wider rounded-xl transition-all shadow-md"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>View Complete Profile</span>
                  </motion.button>
                </div>
              ))}
            </div>
          )}

          {/* Pagination Controls */}
          {totalUserPages > 1 && (
            <div className="flex items-center justify-between pt-4 text-xs">
              <span className="text-zinc-500">
                Page {userPage} of {totalUserPages} ({filteredUsers.length} total users)
              </span>
              <div className="flex items-center gap-2">
                <button
                  disabled={userPage === 1}
                  onClick={() => setUserPage((p) => Math.max(1, p - 1))}
                  className="p-2 bg-zinc-900 text-white rounded-xl border border-zinc-800 disabled:opacity-40"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button
                  disabled={userPage === totalUserPages}
                  onClick={() => setUserPage((p) => Math.min(totalUserPages, p + 1))}
                  className="p-2 bg-zinc-900 text-white rounded-xl border border-zinc-800 disabled:opacity-40"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 3. APPLICATION MANAGEMENT TAB */}
      {activeTab === 'applications' && (
        <div className="space-y-6">
          {/* Search & Filter Controls */}
          <div className="bg-zinc-950 border border-zinc-800/90 rounded-3xl p-5 space-y-4">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="relative w-full sm:w-1/3">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
                <input
                  type="text"
                  value={appSearch}
                  onChange={(e) => {
                    setAppSearch(e.target.value);
                    setAppPage(1);
                  }}
                  placeholder="Search by applicant, email, position..."
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-2xl py-2.5 pl-11 pr-4 text-xs text-white outline-none"
                />
              </div>

              <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto text-xs">
                <div className="flex items-center gap-1.5">
                  <span className="text-zinc-400 font-semibold">Queue:</span>
                  <select
                    value={appQueueFilter}
                    onChange={(e) => {
                      setAppQueueFilter(e.target.value);
                      setAppPage(1);
                    }}
                    className="bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-1.5 text-xs text-white outline-none"
                  >
                    <option value="All">All Queues</option>
                    <option value="Staff Review">Staff Review</option>
                    <option value="Mod Review">Mod Review</option>
                    <option value="Admin Review">Admin Review</option>
                  </select>
                </div>

                <div className="flex items-center gap-1.5">
                  <span className="text-zinc-400 font-semibold">Status:</span>
                  <select
                    value={appStatusFilter}
                    onChange={(e) => {
                      setAppStatusFilter(e.target.value);
                      setAppPage(1);
                    }}
                    className="bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-1.5 text-xs text-white outline-none"
                  >
                    <option value="All">All Active Statuses</option>
                    <option value="Pending">Pending</option>
                    <option value="Under Review">Under Review</option>
                    <option value="Accepted">Accepted</option>
                  </select>
                </div>

                <div className="flex items-center gap-1.5">
                  <span className="text-zinc-400 font-semibold">Sort:</span>
                  <select
                    value={appSort}
                    onChange={(e) => setAppSort(e.target.value as 'newest' | 'oldest')}
                    className="bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-1.5 text-xs text-white outline-none"
                  >
                    <option value="newest">Newest First</option>
                    <option value="oldest">Oldest First</option>
                  </select>
                </div>
              </div>
            </div>
          </div>

          {/* Applications List */}
          {paginatedApps.length === 0 ? (
            <div className="bg-zinc-950 border border-zinc-800/90 rounded-3xl p-12 text-center text-xs text-zinc-500">
              No applications found.
            </div>
          ) : (
            <div className="space-y-4">
              {paginatedApps.map((app) => {
                const isAnimatingThis = animatingDecision?.id === app.id;
                return (
                  <motion.div
                    key={app.id}
                    layout
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-zinc-950 border border-zinc-800/90 rounded-3xl p-6 space-y-4 hover:border-zinc-700 transition-colors shadow-xl relative overflow-hidden"
                  >
                    <AnimatePresence>
                      {isAnimatingThis && animatingDecision && (
                        <ApplicationActionAnimation
                          status={animatingDecision.status}
                          applicantName={animatingDecision.name}
                          position={animatingDecision.position}
                        />
                      )}
                    </AnimatePresence>

                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-zinc-900 pb-3">
                      <div>
                        <span className="text-[10px] text-zinc-500 font-mono">App ID: {app.id}</span>
                        <h4 className="text-lg font-black text-white">{app.applicantName} ({app.discordUsername})</h4>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-indigo-400 bg-indigo-950/60 border border-indigo-800 px-3 py-1 rounded-xl">
                          Queue: {app.queue || 'Staff Review'}
                        </span>
                        <span className="text-xs font-bold text-orange-400 bg-zinc-900 px-3 py-1 rounded-xl">
                          {app.category}
                        </span>
                        <span className="text-xs font-bold text-amber-300 bg-amber-950/80 px-3 py-1 rounded-xl uppercase">
                          {app.status}
                        </span>
                      </div>
                    </div>

                    {/* Reviewer Assignment Row */}
                    <div className="flex flex-wrap items-center justify-between gap-3 text-xs bg-zinc-900/40 p-3 rounded-2xl border border-zinc-800">
                      <div className="text-zinc-400">
                        Assigned Reviewer:{' '}
                        <strong className="text-amber-400">
                          {app.assignedReviewerName ? `${app.assignedReviewerName} (Assigned)` : 'Unassigned'}
                        </strong>
                      </div>

                      <div className="flex items-center gap-2">
                        <select
                          onChange={(e) => setReviewerAssignmentUid(e.target.value)}
                          className="bg-zinc-950 border border-zinc-800 rounded-xl px-2.5 py-1 text-xs text-white outline-none"
                        >
                          <option value="">Assign to Staff Member...</option>
                          {users
                            .filter((u) => u.role !== 'USER')
                            .map((staffMember) => (
                              <option key={staffMember.uid} value={staffMember.uid}>
                                {staffMember.name} ({staffMember.role})
                              </option>
                            ))}
                        </select>
                        <button
                          onClick={() => handleAssignReviewer(app.id!)}
                          disabled={!reviewerAssignmentUid}
                          className="px-3 py-1 bg-amber-500 hover:bg-amber-400 text-black font-extrabold text-[11px] rounded-xl disabled:opacity-40"
                        >
                          Assign
                        </button>
                      </div>
                    </div>

                    {/* Answers */}
                    <div className="space-y-4 text-xs">
                        {QUESTIONS[app.category].map((q, i) => (
                            <div key={i} className="bg-zinc-900/60 p-4 rounded-2xl border border-zinc-800">
                                <strong className="text-orange-400 block mb-1 uppercase">{q}</strong>
                                <p className="text-zinc-300 leading-relaxed">{app.answers[i.toString()] || 'No answer provided.'}</p>
                            </div>
                        ))}
                    </div>

                    {/* Decision controls */}
                    <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-3">
                      <input
                        type="text"
                        placeholder="Add owner evaluation note..."
                        onChange={(e) => setReviewNote(e.target.value)}
                        className="w-full sm:w-1/2 bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2 text-xs text-white outline-none"
                      />
                      <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                        <motion.button
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                          disabled={processingId === app.id}
                          onClick={() => handleOwnerDecision(app.id!, 'Under Review')}
                          className="px-3.5 py-1.5 bg-indigo-950 hover:bg-indigo-900 text-indigo-300 border border-indigo-800 text-xs font-bold rounded-xl disabled:opacity-50"
                        >
                          Under Review
                        </motion.button>
                        <motion.button
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                          disabled={processingId === app.id}
                          onClick={() => handleOwnerDecision(app.id!, 'Accepted')}
                          className="px-3.5 py-1.5 bg-emerald-950 hover:bg-emerald-900 text-emerald-300 border border-emerald-800 text-xs font-bold rounded-xl shadow-md disabled:opacity-50"
                        >
                          {processingId === app.id ? 'Saving...' : 'Accept'}
                        </motion.button>
                        <motion.button
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                          disabled={processingId === app.id}
                          onClick={() => handleOwnerDecision(app.id!, 'Rejected')}
                          className="px-3.5 py-1.5 bg-red-950 hover:bg-red-900 text-red-300 border border-red-800 text-xs font-bold rounded-xl shadow-md disabled:opacity-50"
                        >
                          {processingId === app.id ? 'Saving...' : 'Reject'}
                        </motion.button>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          )}

          {/* App Pagination */}
          {totalAppPages > 1 && (
            <div className="flex items-center justify-between pt-4 text-xs">
              <span className="text-zinc-500">
                Page {appPage} of {totalAppPages} ({filteredApps.length} total applications)
              </span>
              <div className="flex items-center gap-2">
                <button
                  disabled={appPage === 1}
                  onClick={() => setAppPage((p) => Math.max(1, p - 1))}
                  className="p-2 bg-zinc-900 text-white rounded-xl border border-zinc-800 disabled:opacity-40"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button
                  disabled={appPage === totalAppPages}
                  onClick={() => setAppPage((p) => Math.min(totalAppPages, p + 1))}
                  className="p-2 bg-zinc-900 text-white rounded-xl border border-zinc-800 disabled:opacity-40"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 4. REPORTS TAB */}
      {activeTab === 'reports' && (
        <div className="space-y-4">
          <h3 className="text-sm font-extrabold text-white uppercase tracking-wider">
            All Incident Reports ({reports.length})
          </h3>

          {reports.length === 0 ? (
            <div className="bg-zinc-950 border border-zinc-800/90 rounded-3xl p-12 text-center text-xs text-zinc-500">
              No reports available.
            </div>
          ) : (
            <div className="space-y-3">
              {reports.map((r) => (
                <div key={r.id} className="bg-zinc-950 border border-zinc-800/90 rounded-2xl p-5 space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-white text-sm">{r.subject}</span>
                    <span className="text-amber-400 font-bold uppercase">{r.status}</span>
                  </div>
                  <div className="text-xs text-zinc-400">By {r.authorName} ({r.authorEmail}) • Category: {r.reportType}</div>
                  <p className="text-xs text-zinc-300 bg-zinc-900/60 p-3 rounded-xl">{r.description}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* 5. SECURITY AUDIT TAB */}
      {activeTab === 'security' && (
        <div className="space-y-4">
          <h3 className="text-sm font-extrabold text-white uppercase tracking-wider">
            Security Audit Log Vault ({auditLogs.length})
          </h3>

          <div className="space-y-2 max-h-[600px] overflow-y-auto pr-1">
            {auditLogs.map((log) => (
              <div key={log.id} className="bg-zinc-950 border border-zinc-800/80 rounded-2xl p-4 text-xs space-y-1">
                <div className="flex items-center justify-between text-zinc-400">
                  <span className="font-extrabold text-white">{log.actorName} ({log.actorEmail})</span>
                  <span>{new Date(log.timestamp).toLocaleString()}</span>
                </div>
                <div className="text-amber-400 font-extrabold">ACTION: {log.action}</div>
                <div className="text-zinc-500 font-mono text-[11px]">
                  Actor Role: {log.actorRole} | Target: {log.targetResource} {log.targetUid}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 6. SETTINGS TAB */}
      {activeTab === 'settings' && (
        <div className="bg-zinc-950 border border-zinc-800/90 rounded-3xl p-6 sm:p-8 space-y-6 max-w-2xl">
          <h3 className="text-base font-extrabold text-white uppercase tracking-wider">
            Global Portal Settings
          </h3>

          <div className="space-y-4 text-xs">
            <div className="flex items-center justify-between p-4 bg-zinc-900/80 rounded-2xl border border-zinc-800">
              <div>
                <strong className="text-white block text-sm">Applications Gateway Status</strong>
                <span className="text-zinc-400">Enable or disable recruitment form submissions.</span>
              </div>
              <input
                type="checkbox"
                checked={appsOpen}
                onChange={(e) => setAppsOpen(e.target.checked)}
                className="w-5 h-5 accent-amber-500 rounded cursor-pointer"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-zinc-300 mb-1.5 uppercase tracking-wider">
                Portal Announcement Banner
              </label>
              <textarea
                value={announcementText}
                onChange={(e) => setAnnouncementText(e.target.value)}
                rows={3}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-3 text-xs text-white outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-zinc-300 mb-1.5 uppercase tracking-wider">
                Staff Requirements Information
              </label>
              <textarea
                value={requirementsText}
                onChange={(e) => setRequirementsText(e.target.value)}
                rows={3}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-3 text-xs text-white outline-none"
              />
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={handleSaveSettings}
                className="px-6 py-2.5 bg-amber-500 hover:bg-amber-400 text-black font-extrabold text-xs uppercase tracking-wider rounded-xl transition-all shadow-md"
              >
                Save System Settings
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Detailed User Profile Modal (On-Demand) */}
      {inspectUser && (
        <UserProfileDetailModal
          user={inspectUser}
          isOpen={!!inspectUser}
          onClose={() => setSelectedInspectUser(null)}
          onProfileUpdated={() => {
            loadOwnerData();
          }}
        />
      )}
    </motion.div>
  );
};
