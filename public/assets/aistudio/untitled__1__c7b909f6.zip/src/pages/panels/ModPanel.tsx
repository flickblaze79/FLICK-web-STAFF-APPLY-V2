import React, { useEffect, useState } from 'react';
import { collection, getDocs, doc, updateDoc, addDoc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../../lib/firebase';
import { useAuth } from '../../context/AuthContext';
import { logAuditEvent } from '../../lib/auditLogger';
import { UserReport, AuditLogEntry } from '../../types';
import { Hammer, MessageSquare, ShieldAlert, CheckCircle2, Clock, Eye, Send, FileText } from 'lucide-react';

export const ModPanel: React.FC = () => {
  const { currentUser, userProfile, isMod } = useAuth();
  const [reports, setReports] = useState<UserReport[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>([]);
  const [loading, setLoading] = useState(true);

  const [selectedReport, setSelectedReport] = useState<UserReport | null>(null);
  const [resolutionNotes, setResolutionNotes] = useState('');
  const [updatingReport, setUpdatingReport] = useState(false);

  useEffect(() => {
    async function loadModData() {
      try {
        const [reportsSnap, logsSnap] = await Promise.all([
          getDocs(collection(db, 'reports')),
          getDocs(collection(db, 'audit_logs')),
        ]);

        const rList: UserReport[] = [];
        reportsSnap.forEach((d) => {
          rList.push({ ...d.data(), id: d.id } as UserReport);
        });
        rList.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        setReports(rList);

        const aList: AuditLogEntry[] = [];
        logsSnap.forEach((d) => {
          aList.push({ ...d.data(), id: d.id } as AuditLogEntry);
        });
        aList.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
        setAuditLogs(aList.slice(0, 30));
      } catch (err) {
        console.error('Error loading mod panel data:', err);
      } finally {
        setLoading(false);
      }
    }

    if (isMod) {
      loadModData();
    }
  }, [isMod]);

  if (!isMod) {
    return (
      <div className="max-w-md mx-auto py-20 text-center text-red-400 font-bold text-sm bg-zinc-950 border border-red-900/50 rounded-2xl p-8 mt-10">
        Access Denied: You do not have Moderator permissions.
      </div>
    );
  }

  const handleResolveReport = async (status: 'Reviewing' | 'Resolved' | 'Rejected') => {
    if (!selectedReport || !selectedReport.id || !currentUser) return;
    setUpdatingReport(true);

    try {
      const repRef = doc(db, 'reports', selectedReport.id);
      const updates = {
        status,
        assignedToUid: currentUser.uid,
        resolutionNotes: resolutionNotes.trim() || selectedReport.resolutionNotes || '',
        updatedAt: new Date().toISOString(),
      };

      await updateDoc(repRef, updates);

      // Create notification for author
      await addDoc(collection(db, 'notifications'), {
        recipientUid: selectedReport.authorUid,
        title: `Report Status Update: ${status}`,
        message: `Your report regarding "${selectedReport.subject}" was marked as ${status}.${resolutionNotes ? ` Resolution note: ${resolutionNotes}` : ''}`,
        type: 'report',
        read: false,
        createdAt: new Date().toISOString(),
      });

      // Audit Log
      await logAuditEvent({
        action: `REPORT_UPDATED_${status.toUpperCase()}`,
        actorUid: currentUser.uid,
        actorName: userProfile?.name || 'Moderator',
        actorEmail: currentUser.email || '',
        actorRole: userProfile?.role || 'MOD',
        targetResource: 'reports',
        targetUid: selectedReport.id,
        metadata: { resolutionNotes },
      });

      setReports((prev) =>
        prev.map((r) => (r.id === selectedReport.id ? { ...r, ...updates } : r))
      );
      setSelectedReport((prev) => (prev ? { ...prev, ...updates } : null));
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `reports/${selectedReport.id}`);
    } finally {
      setUpdatingReport(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto py-8 px-4 space-y-8">
      {/* Header */}
      <div className="border-b border-zinc-800/80 pb-6 flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold text-emerald-400 uppercase tracking-widest">
            <Hammer className="w-4 h-4" />
            <span>Moderation Operations</span>
          </div>
          <h1 className="text-3xl font-black text-white uppercase tracking-tight mt-1">
            Moderator Panel
          </h1>
          <p className="text-xs text-zinc-400">
            Handle user reports, inspect community safety cases, and view moderation logs.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Reports List */}
        <div className="lg:col-span-1 space-y-3">
          <h3 className="text-xs font-bold text-zinc-400 uppercase tracking-wider px-1">
            Community Reports ({reports.length})
          </h3>

          {loading ? (
            <div className="text-xs text-zinc-500 py-8 text-center">Loading reports...</div>
          ) : reports.length === 0 ? (
            <div className="bg-zinc-950 border border-zinc-800 rounded-2xl p-6 text-center text-xs text-zinc-500">
              No active reports found.
            </div>
          ) : (
            <div className="space-y-2.5 max-h-[600px] overflow-y-auto pr-1">
              {reports.map((rep) => {
                const isSelected = selectedReport?.id === rep.id;
                return (
                  <button
                    key={rep.id}
                    onClick={() => {
                      setSelectedReport(rep);
                      setResolutionNotes(rep.resolutionNotes || '');
                    }}
                    className={`w-full text-left p-4 rounded-2xl border transition-all ${
                      isSelected
                        ? 'bg-zinc-800/90 border-emerald-500 shadow-md'
                        : 'bg-zinc-950 border-zinc-800/80 hover:border-zinc-700'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-extrabold text-white truncate max-w-[180px]">
                        {rep.subject}
                      </span>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-zinc-900 text-emerald-400 uppercase">
                        {rep.status}
                      </span>
                    </div>
                    <div className="text-[11px] text-zinc-400 mt-1 flex items-center justify-between">
                      <span>{rep.reportType}</span>
                      <span className="text-zinc-500">{new Date(rep.createdAt).toLocaleDateString()}</span>
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Selected Report Inspection & Action */}
        <div className="lg:col-span-2 space-y-6">
          {selectedReport ? (
            <div className="bg-zinc-950 border border-zinc-800/90 rounded-3xl p-6 sm:p-8 space-y-6 shadow-2xl">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-zinc-900 pb-4">
                <div>
                  <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">
                    Report ID: {selectedReport.id}
                  </span>
                  <h2 className="text-xl font-extrabold text-white mt-0.5">
                    {selectedReport.subject}
                  </h2>
                </div>
                <span className="text-xs font-bold text-emerald-400 bg-emerald-950/60 border border-emerald-800 px-3 py-1 rounded-xl uppercase">
                  Status: {selectedReport.status}
                </span>
              </div>

              {/* Author Metadata */}
              <div className="grid grid-cols-2 gap-4 text-xs bg-zinc-900/60 border border-zinc-800/60 p-4 rounded-2xl">
                <div>
                  <span className="text-zinc-500 block uppercase text-[10px] font-bold">Reported By</span>
                  <span className="text-zinc-200 font-bold">{selectedReport.authorName} ({selectedReport.authorEmail})</span>
                </div>
                <div>
                  <span className="text-zinc-500 block uppercase text-[10px] font-bold">Category</span>
                  <span className="text-orange-400 font-bold">{selectedReport.reportType}</span>
                </div>
              </div>

              <div>
                <span className="text-xs font-bold text-zinc-400 uppercase tracking-wider block mb-1">
                  Incident Description
                </span>
                <p className="bg-zinc-900/80 p-4 rounded-2xl border border-zinc-800 text-xs text-zinc-200 leading-relaxed">
                  {selectedReport.description}
                </p>
              </div>

              {/* Resolution Controls */}
              <div className="pt-4 border-t border-zinc-900 space-y-4">
                <h4 className="text-xs font-extrabold text-white uppercase tracking-wider">
                  Moderator Resolution & Notes
                </h4>

                <textarea
                  value={resolutionNotes}
                  onChange={(e) => setResolutionNotes(e.target.value)}
                  placeholder="Enter moderation findings or resolution notes..."
                  rows={3}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-3 text-xs text-white outline-none focus:border-emerald-500"
                />

                <div className="flex flex-wrap items-center gap-3">
                  <button
                    onClick={() => handleResolveReport('Reviewing')}
                    disabled={updatingReport}
                    className="px-4 py-2 bg-indigo-950 hover:bg-indigo-900 text-indigo-300 border border-indigo-800 font-bold text-xs rounded-xl transition-all"
                  >
                    Set "Reviewing"
                  </button>

                  <button
                    onClick={() => handleResolveReport('Resolved')}
                    disabled={updatingReport}
                    className="px-4 py-2 bg-emerald-950 hover:bg-emerald-900 text-emerald-300 border border-emerald-800 font-bold text-xs rounded-xl transition-all"
                  >
                    Mark "Resolved"
                  </button>

                  <button
                    onClick={() => handleResolveReport('Rejected')}
                    disabled={updatingReport}
                    className="px-4 py-2 bg-red-950 hover:bg-red-900 text-red-300 border border-red-800 font-bold text-xs rounded-xl transition-all"
                  >
                    Dismiss / Reject
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-zinc-950 border border-zinc-800/80 rounded-3xl p-12 text-center text-zinc-500 text-xs space-y-2">
              <Eye className="w-8 h-8 mx-auto text-zinc-600" />
              <p>Select a report from the list to inspect details and issue moderation actions.</p>
            </div>
          )}

          {/* Audit Logs Feed */}
          <div className="bg-zinc-950 border border-zinc-800/90 rounded-3xl p-6 space-y-4">
            <h3 className="text-xs font-extrabold text-zinc-300 uppercase tracking-wider">
              Recent Moderation Audit Activity
            </h3>
            <div className="space-y-2 max-h-48 overflow-y-auto text-xs">
              {auditLogs.map((log) => (
                <div key={log.id} className="p-2.5 bg-zinc-900/60 rounded-xl border border-zinc-800/60 flex items-center justify-between text-[11px]">
                  <div>
                    <span className="font-bold text-white">{log.actorName}</span>{' '}
                    <span className="text-zinc-400">({log.actorRole}):</span>{' '}
                    <span className="text-orange-400">{log.action}</span>
                  </div>
                  <span className="text-zinc-500">{new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
