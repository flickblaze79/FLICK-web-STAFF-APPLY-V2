import React, { useEffect, useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { collection, getDocs, doc, updateDoc, addDoc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../../lib/firebase';
import { useAuth } from '../../context/AuthContext';
import { logAuditEvent } from '../../lib/auditLogger';
import { StaffApplication, QUESTIONS } from '../../types';
import { ApplicationActionAnimation } from '../../components/ApplicationActionAnimation';
import { Shield, Search, CheckCircle2, XCircle, Clock, Eye, Send, FileText, ChevronLeft, ChevronRight, AlertCircle } from 'lucide-react';

export const StaffPanel: React.FC = () => {
  const { currentUser, userProfile, isStaff } = useAuth();
  const [applications, setApplications] = useState<StaffApplication[]>([]);
  const [loading, setLoading] = useState(true);

  const [selectedApp, setSelectedApp] = useState<StaffApplication | null>(null);
  const [reviewNote, setReviewNote] = useState('');
  const [submittingNote, setSubmittingNote] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);

  // Accept / Reject animation overlay state
  const [animatingDecision, setAnimatingDecision] = useState<'Accepted' | 'Rejected' | null>(null);

  // Search & Filters
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('All');
  const [positionFilter, setPositionFilter] = useState<string>('All');
  const [currentPage, setCurrentPage] = useState(1);
  const ITEMS_PER_PAGE = 8;

  useEffect(() => {
    async function loadApplications() {
      try {
        const snap = await getDocs(collection(db, 'applications'));
        const list: StaffApplication[] = [];
        snap.forEach((d) => {
          list.push({ ...d.data(), id: d.id } as StaffApplication);
        });
        list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        setApplications(list);
      } catch (err) {
        console.error('Error loading applications for staff panel:', err);
      } finally {
        setLoading(false);
      }
    }

    if (isStaff) {
      loadApplications();
    }
  }, [isStaff]);

  const filteredApps = useMemo(() => {
    return applications.filter((app) => {
      // REJECTED APPLICATION VISIBILITY RULE: Once rejected, an application must NEVER appear in any staff/mod/admin/owner list or filter
      if (app.status === 'Rejected') return false;
      const matchesSearch =
        app.applicantName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        app.discordUsername.toLowerCase().includes(searchTerm.toLowerCase()) ||
        app.applicantEmail.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesStatus = filterStatus === 'All' || app.status === filterStatus;
      const matchesPosition = positionFilter === 'All' || app.position === positionFilter;
      return matchesSearch && matchesStatus && matchesPosition;
    });
  }, [applications, searchTerm, filterStatus, positionFilter]);

  const totalPages = Math.ceil(filteredApps.length / ITEMS_PER_PAGE) || 1;
  const paginatedApps = useMemo(() => {
    const start = (currentPage - 1) * ITEMS_PER_PAGE;
    return filteredApps.slice(start, start + ITEMS_PER_PAGE);
  }, [filteredApps, currentPage]);

  if (!isStaff) {
    return (
      <div className="max-w-md mx-auto py-20 text-center text-red-400 font-bold text-sm bg-zinc-950 border border-red-900/50 rounded-2xl p-8 mt-10">
        Access Denied: You do not have Staff permissions.
      </div>
    );
  }

  // ACCEPT / REJECT / UNDER REVIEW FLOW WITH FIREBASE NOTIFICATION & ANIMATION
  const handleUpdateStatus = async (newStatus: 'Under Review' | 'Accepted' | 'Rejected') => {
    if (!selectedApp || !selectedApp.id || !currentUser || submittingNote) return;
    setActionError(null);
    setSubmittingNote(true);

    try {
      const appRef = doc(db, 'applications', selectedApp.id);
      const updates = {
        status: newStatus,
        reviewerUid: currentUser.uid,
        reviewerRole: userProfile?.role || 'STAFF',
        reviewNotes: reviewNote.trim() || selectedApp.reviewNotes || '',
        updatedAt: new Date().toISOString(),
      };

      // 1. REAL FIREBASE FIRESTORE UPDATE
      await updateDoc(appRef, updates);

      // 2. REAL FIREBASE NOTIFICATION
      let notifMessage = `Your staff application for ${selectedApp.position} status was changed to ${newStatus}.${reviewNote ? ` Note: ${reviewNote}` : ''}`;
      if (newStatus === 'Accepted') {
        notifMessage = `Your Staff Application has been Accepted. Role: ${selectedApp.position}`;
      } else if (newStatus === 'Rejected') {
        notifMessage = `Your Staff Application has been Rejected.`;
      }

      await addDoc(collection(db, 'notifications'), {
        recipientUid: selectedApp.applicantUid,
        title: `Staff Application Update: ${newStatus}`,
        message: notifMessage,
        type: 'application',
        read: false,
        createdAt: new Date().toISOString(),
      });

      // 3. AUDIT LOG
      await logAuditEvent({
        action: `STAFF_RECOMMENDED_${newStatus.toUpperCase().replace(' ', '_')}`,
        actorUid: currentUser.uid,
        actorName: userProfile?.name || 'Staff',
        actorEmail: currentUser.email || '',
        actorRole: userProfile?.role || 'STAFF',
        targetResource: 'applications',
        targetUid: selectedApp.id,
        metadata: { position: selectedApp.position, reviewNotes: reviewNote },
      });

      // Update local state
      setApplications((prev) =>
        prev.map((a) => (a.id === selectedApp.id ? { ...a, ...updates } : a))
      );
      const updatedApp = { ...selectedApp, ...updates };
      setSelectedApp(updatedApp);

      // 4. PLAY SUCCESS ANIMATION IF ACCEPTED OR REJECTED
      if (newStatus === 'Accepted' || newStatus === 'Rejected') {
        setAnimatingDecision(newStatus);
        setTimeout(() => {
          setAnimatingDecision(null);
          setSelectedApp(null);
        }, 1300);
      }
    } catch (err: any) {
      console.error('Error updating status:', err);
      setActionError(err?.message || 'Failed to update application status in Firebase.');
    } finally {
      setSubmittingNote(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="max-w-7xl mx-auto py-8 px-4 space-y-8"
    >
      {/* Header */}
      <div className="border-b border-zinc-800/80 pb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold text-blue-400 uppercase tracking-widest">
            <Shield className="w-4 h-4" />
            <span>Authorized Operations</span>
          </div>
          <h1 className="text-3xl font-black text-white uppercase tracking-tight mt-1">
            Staff Panel
          </h1>
          <p className="text-xs text-zinc-400">
            Review applicant profiles, add recommendation notes, and monitor submission pipelines.
          </p>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-zinc-500" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setCurrentPage(1);
              }}
              placeholder="Search..."
              className="bg-zinc-900 border border-zinc-800 rounded-xl py-1.5 pl-9 pr-3 text-xs text-white outline-none focus:border-blue-500"
            />
          </div>

          <select
            value={filterStatus}
            onChange={(e) => {
              setFilterStatus(e.target.value);
              setCurrentPage(1);
            }}
            className="bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-1.5 text-xs text-white outline-none"
          >
            <option value="All">All Active Statuses</option>
            <option value="Pending">Pending</option>
            <option value="Under Review">Under Review</option>
            <option value="Accepted">Accepted</option>
          </select>

          <select
            value={positionFilter}
            onChange={(e) => {
              setPositionFilter(e.target.value);
              setCurrentPage(1);
            }}
            className="bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-1.5 text-xs text-white outline-none"
          >
            <option value="All">All Positions</option>
            <option value="Helper">Helper</option>
            <option value="Moderator">Moderator</option>
            <option value="Senior Moderator">Senior Moderator</option>
            <option value="Staff">Staff</option>
            <option value="Admin">Admin</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Applications List */}
        <div className="lg:col-span-1 space-y-3">
          <h3 className="text-xs font-bold text-zinc-400 uppercase tracking-wider px-1">
            Applications ({filteredApps.length})
          </h3>

          {loading ? (
            <div className="text-xs text-zinc-500 py-8 text-center">Loading applications...</div>
          ) : paginatedApps.length === 0 ? (
            <div className="bg-zinc-950 border border-zinc-800 rounded-2xl p-6 text-center text-xs text-zinc-500">
              No applications match filter.
            </div>
          ) : (
            <div className="space-y-2.5 max-h-[600px] overflow-y-auto pr-1">
              {paginatedApps.map((app) => {
                const isSelected = selectedApp?.id === app.id;
                return (
                  <motion.button
                    key={app.id}
                    whileHover={{ scale: 1.01 }}
                    whileTap={{ scale: 0.99 }}
                    onClick={() => {
                      setSelectedApp(app);
                      setReviewNote(app.reviewNotes || '');
                      setActionError(null);
                    }}
                    className={`w-full text-left p-4 rounded-2xl border transition-all relative ${
                      isSelected
                        ? 'bg-zinc-800/90 border-blue-500 shadow-md'
                        : 'bg-zinc-950 border-zinc-800/80 hover:border-zinc-700'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-extrabold text-white">{app.applicantName}</span>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-zinc-900 text-orange-400 uppercase">
                        {app.position}
                      </span>
                    </div>
                    <div className="text-[11px] text-zinc-400 mt-1 flex items-center justify-between">
                      <span>{app.discordUsername}</span>
                      <span className="text-zinc-500">{new Date(app.createdAt).toLocaleDateString()}</span>
                    </div>
                  </motion.button>
                );
              })}
            </div>
          )}

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between pt-2 text-xs text-zinc-400">
              <span>Page {currentPage} of {totalPages}</span>
              <div className="flex items-center gap-2">
                <button
                  disabled={currentPage === 1}
                  onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                  className="p-1.5 bg-zinc-900 rounded-lg border border-zinc-800 disabled:opacity-40"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button
                  disabled={currentPage === totalPages}
                  onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                  className="p-1.5 bg-zinc-900 rounded-lg border border-zinc-800 disabled:opacity-40"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Selected Application Details & Review */}
        <div className="lg:col-span-2 relative">
          <AnimatePresence mode="wait">
            {selectedApp ? (
              <motion.div
                key={selectedApp.id}
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98 }}
                transition={{ duration: 0.2 }}
                className="bg-zinc-950 border border-zinc-800/90 rounded-3xl p-6 sm:p-8 space-y-6 shadow-2xl relative overflow-hidden"
              >
                {/* Decision Animation Overlay */}
                <AnimatePresence>
                  {animatingDecision && (
                    <ApplicationActionAnimation
                      status={animatingDecision}
                      applicantName={selectedApp.applicantName}
                      position={selectedApp.position}
                    />
                  )}
                </AnimatePresence>

                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-zinc-900 pb-4">
                  <div>
                    <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">
                      ID: {selectedApp.id}
                    </span>
                    <h2 className="text-xl font-extrabold text-white mt-0.5">
                      {selectedApp.applicantName}
                    </h2>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-orange-400 bg-orange-950/60 border border-orange-800 px-3 py-1 rounded-xl">
                      Category: {selectedApp.category}
                    </span>
                    <span className="text-xs font-bold text-zinc-300 bg-zinc-900 px-3 py-1 rounded-xl uppercase">
                      Status: {selectedApp.status}
                    </span>
                  </div>
                </div>

                {actionError && (
                  <div className="p-3 bg-red-950/80 border border-red-800 rounded-xl text-red-200 text-xs flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                    <span>{actionError}</span>
                  </div>
                )}

                {/* Applicant Metadata */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs bg-zinc-900/60 border border-zinc-800/60 p-4 rounded-2xl">
                  <div>
                    <span className="text-zinc-500 block uppercase text-[10px] font-bold">Email</span>
                    <span className="text-zinc-200">{selectedApp.applicantEmail}</span>
                  </div>
                  <div>
                    <span className="text-zinc-500 block uppercase text-[10px] font-bold">Discord</span>
                    <span className="text-indigo-400 font-bold">{selectedApp.discordUsername}</span>
                  </div>
                  <div>
                    <span className="text-zinc-500 block uppercase text-[10px] font-bold">Age / Timezone</span>
                    <span className="text-zinc-200">{selectedApp.age} y/o • {selectedApp.timezone}</span>
                  </div>
                  <div>
                    <span className="text-zinc-500 block uppercase text-[10px] font-bold">Available Hours</span>
                    <span className="text-zinc-200">{selectedApp.availableHours}</span>
                  </div>
                </div>

                {/* Questions & Answers */}
                <div className="space-y-4 text-xs">
                  {QUESTIONS[selectedApp.category].map((q, i) => (
                    <div key={i}>
                      <span className="font-bold text-orange-400 block mb-1 uppercase tracking-wider">
                        {q}
                      </span>
                      <p className="bg-zinc-900/80 p-3 rounded-xl border border-zinc-800 text-zinc-300 leading-relaxed">
                        {selectedApp.answers[i.toString()] || 'No answer provided.'}
                      </p>
                    </div>
                  ))}
                </div>

                {/* Staff Actions & Review Notes */}
                <div className="pt-4 border-t border-zinc-900 space-y-4">
                  <h4 className="text-xs font-extrabold text-white uppercase tracking-wider">
                    Staff Recommendation & Review Notes
                  </h4>

                  <textarea
                    value={reviewNote}
                    onChange={(e) => setReviewNote(e.target.value)}
                    placeholder="Add evaluation comments, recommendation notes, or feedback..."
                    rows={3}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-3 text-xs text-white outline-none focus:border-blue-500"
                  />

                  <div className="flex flex-wrap items-center gap-3">
                    <motion.button
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => handleUpdateStatus('Under Review')}
                      disabled={submittingNote}
                      className="px-4 py-2 bg-indigo-950 hover:bg-indigo-900 text-indigo-300 border border-indigo-800 font-bold text-xs rounded-xl transition-all disabled:opacity-50"
                    >
                      Mark "Under Review"
                    </motion.button>

                    <motion.button
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => handleUpdateStatus('Accepted')}
                      disabled={submittingNote}
                      className="px-4 py-2 bg-emerald-950 hover:bg-emerald-900 text-emerald-300 border border-emerald-800 font-bold text-xs rounded-xl transition-all shadow-md disabled:opacity-50"
                    >
                      {submittingNote ? 'Saving...' : 'Accept Application'}
                    </motion.button>

                    <motion.button
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => handleUpdateStatus('Rejected')}
                      disabled={submittingNote}
                      className="px-4 py-2 bg-red-950 hover:bg-red-900 text-red-300 border border-red-800 font-bold text-xs rounded-xl transition-all shadow-md disabled:opacity-50"
                    >
                      {submittingNote ? 'Saving...' : 'Reject Application'}
                    </motion.button>
                  </div>
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="empty"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="bg-zinc-950 border border-zinc-800/80 rounded-3xl p-12 text-center text-zinc-500 text-xs space-y-2"
              >
                <Eye className="w-8 h-8 mx-auto text-zinc-600" />
                <p>Select an application from the list to view detailed answers and submit staff recommendations.</p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </motion.div>
  );
};
