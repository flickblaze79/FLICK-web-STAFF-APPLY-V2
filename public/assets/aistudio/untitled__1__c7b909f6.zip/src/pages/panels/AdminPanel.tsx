import React, { useEffect, useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { collection, getDocs, doc, updateDoc, setDoc, addDoc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../../lib/firebase';
import { useAuth } from '../../context/AuthContext';
import { logAuditEvent } from '../../lib/auditLogger';
import { StaffApplication, UserProfile, UserRole, AuditLogEntry, QUESTIONS } from '../../types';
import { ApplicationActionAnimation } from '../../components/ApplicationActionAnimation';
import { Settings, Users, FileText, Search, ShieldCheck, CheckCircle2, XCircle, AlertTriangle, Lock, UserX, UserCheck, AlertCircle } from 'lucide-react';

export const AdminPanel: React.FC = () => {
  const { currentUser, userProfile, isAdmin } = useAuth();
  
  const [activeTab, setActiveTab] = useState<'applications' | 'users' | 'audit' | 'settings'>('applications');
  const [applications, setApplications] = useState<StaffApplication[]>([]);
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>([]);
  const [loading, setLoading] = useState(true);

  // Search & Filters
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');

  // Selected App modal / view
  const [selectedApp, setSelectedApp] = useState<StaffApplication | null>(null);
  const [adminNote, setAdminNote] = useState('');
  const [processingId, setProcessingId] = useState<string | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);

  // Decision Animation State
  const [animatingDecision, setAnimatingDecision] = useState<{ id: string; status: 'Accepted' | 'Rejected'; name: string; position: string } | null>(null);

  // Announcement State
  const [announcementText, setAnnouncementText] = useState('FLICK Staff Applications are currently OPEN.');
  const [appsOpen, setAppsOpen] = useState(true);

  useEffect(() => {
    async function loadAdminData() {
      try {
        const [appsSnap, usersSnap, logsSnap] = await Promise.all([
          getDocs(collection(db, 'applications')),
          getDocs(collection(db, 'users')),
          getDocs(collection(db, 'audit_logs')),
        ]);

        const aList: StaffApplication[] = [];
        appsSnap.forEach((d) => aList.push({ ...d.data(), id: d.id } as StaffApplication));
        aList.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        setApplications(aList);

        const uList: UserProfile[] = [];
        usersSnap.forEach((d) => {
          const data = d.data();
          uList.push({ ...data, uid: d.id } as UserProfile);
        });
        setUsers(uList);

        const lList: AuditLogEntry[] = [];
        logsSnap.forEach((d) => {
          const data = d.data();
          lList.push({ ...data, id: d.id } as AuditLogEntry);
        });
        lList.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
        setAuditLogs(lList);
      } catch (err) {
        console.error('Error loading admin data:', err);
      } finally {
        setLoading(false);
      }
    }

    if (isAdmin) {
      loadAdminData();
    }
  }, [isAdmin]);

  if (!isAdmin) {
    return (
      <div className="max-w-md mx-auto py-20 text-center text-red-400 font-bold text-sm bg-zinc-950 border border-red-900/50 rounded-2xl p-8 mt-10">
        Access Denied: You do not have Admin permissions.
      </div>
    );
  }

  // Application Decision with Animation & Real Notification
  const handleDecision = async (appId: string, status: 'Accepted' | 'Rejected' | 'Under Review') => {
    if (!currentUser || processingId === appId) return;
    const targetApp = applications.find((a) => a.id === appId);
    if (!targetApp) return;

    setActionError(null);
    setProcessingId(appId);

    try {
      const ref = doc(db, 'applications', appId);
      const updates = {
        status,
        reviewerUid: currentUser.uid,
        reviewerRole: userProfile?.role || 'ADMIN',
        reviewNotes: adminNote.trim() || targetApp.reviewNotes || '',
        updatedAt: new Date().toISOString(),
      };

      // 1. SAVE TO FIREBASE
      await updateDoc(ref, updates);

      // 2. REAL FIREBASE NOTIFICATION FOR APPLICANT
      let notifMessage = `Your staff application for ${targetApp.position} status was changed to ${status} by Administration.`;
      if (status === 'Accepted') {
        notifMessage = `Your Staff Application has been Accepted. Position: ${targetApp.position}`;
      } else if (status === 'Rejected') {
        notifMessage = `Your Staff Application has been Rejected.`;
      }

      await addDoc(collection(db, 'notifications'), {
        recipientUid: targetApp.applicantUid,
        title: `Application Decision: ${status}`,
        message: notifMessage,
        type: 'application',
        read: false,
        createdAt: new Date().toISOString(),
      });

      // 3. AUDIT LOG
      await logAuditEvent({
        action: `ADMIN_DECISION_${status.toUpperCase()}`,
        actorUid: currentUser.uid,
        actorName: userProfile?.name || 'Admin',
        actorEmail: currentUser.email || '',
        actorRole: userProfile?.role || 'ADMIN',
        targetResource: 'applications',
        targetUid: appId,
        metadata: { position: targetApp.position, newStatus: status },
      });

      setApplications((prev) =>
        prev.map((a) => (a.id === appId ? { ...a, ...updates } : a))
      );

      // 4. ANIMATION OVERLAY IF ACCEPTED OR REJECTED
      if (status === 'Accepted' || status === 'Rejected') {
        setAnimatingDecision({ id: appId, status, name: targetApp.applicantName, position: targetApp.position });
        setTimeout(() => {
          setAnimatingDecision(null);
        }, 1300);
      }
    } catch (err: any) {
      console.error('Error in decision:', err);
      setActionError(err?.message || 'Failed to process decision in Firebase.');
    } finally {
      setProcessingId(null);
    }
  };

  // Change User Role
  const handleRoleChange = async (targetUid: string, newRole: UserRole) => {
    if (!currentUser) return;
    const targetUser = users.find((u) => u.uid === targetUid);
    if (!targetUser) return;

    if (targetUser.role === 'OWNER') {
      alert('Admins cannot modify Owner roles.');
      return;
    }
    if (newRole === 'OWNER') {
      alert('Only Owners can assign the Owner role.');
      return;
    }

    try {
      const userRef = doc(db, 'users', targetUid);
      await updateDoc(userRef, { role: newRole });

      await logAuditEvent({
        action: 'ADMIN_ROLE_CHANGE',
        actorUid: currentUser.uid,
        actorName: userProfile?.name || 'Admin',
        actorEmail: currentUser.email || '',
        actorRole: userProfile?.role || 'ADMIN',
        targetResource: 'users',
        targetUid,
        metadata: { previousRole: targetUser.role, newRole },
      });

      setUsers((prev) =>
        prev.map((u) => (u.uid === targetUid ? { ...u, role: newRole } : u))
      );
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${targetUid}`);
    }
  };

  // Toggle Suspend Status
  const handleToggleSuspend = async (targetUid: string, currentSuspended?: boolean) => {
    if (!currentUser) return;
    const targetUser = users.find((u) => u.uid === targetUid);
    if (targetUser?.role === 'OWNER') {
      alert('Owners cannot be suspended by Admins.');
      return;
    }

    const nextState = !currentSuspended;
    try {
      const userRef = doc(db, 'users', targetUid);
      await updateDoc(userRef, { isSuspended: nextState });

      await logAuditEvent({
        action: nextState ? 'USER_SUSPENDED' : 'USER_ACTIVATED',
        actorUid: currentUser.uid,
        actorName: userProfile?.name || 'Admin',
        actorEmail: currentUser.email || '',
        actorRole: userProfile?.role || 'ADMIN',
        targetResource: 'users',
        targetUid,
        metadata: { isSuspended: nextState },
      });

      setUsers((prev) =>
        prev.map((u) => (u.uid === targetUid ? { ...u, isSuspended: nextState } : u))
      );
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${targetUid}`);
    }
  };

  // Save System Settings
  const handleSaveSettings = async () => {
    if (!currentUser) return;
    try {
      await setDoc(
        doc(db, 'system_settings', 'global'),
        {
          applicationsOpen: appsOpen,
          announcementText,
          updatedAt: new Date().toISOString(),
        },
        { merge: true }
      );

      await logAuditEvent({
        action: 'SYSTEM_SETTINGS_UPDATED',
        actorUid: currentUser.uid,
        actorName: userProfile?.name || 'Admin',
        actorEmail: currentUser.email || '',
        actorRole: userProfile?.role || 'ADMIN',
        targetResource: 'system_settings',
        metadata: { applicationsOpen: appsOpen, announcementText },
      });

      alert('System Settings Saved Successfully!');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'system_settings/global');
    }
  };

  const filteredApplications = useMemo(() => {
    return applications.filter((app) => {
      // REJECTED APPLICATION VISIBILITY RULE: Once rejected, an application must NEVER appear in any staff/mod/admin/owner list or filter
      if (app.status === 'Rejected') return false;
      const matchesSearch =
        app.applicantName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        app.applicantEmail.toLowerCase().includes(searchTerm.toLowerCase()) ||
        app.discordUsername.toLowerCase().includes(searchTerm.toLowerCase()) ||
        app.position.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesStatus = statusFilter === 'All' || app.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [applications, searchTerm, statusFilter]);

  const filteredUsers = useMemo(() => {
    return users.filter((u) =>
      u.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      u.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      u.uid.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [users, searchTerm]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="max-w-7xl mx-auto py-8 px-4 space-y-8"
    >
      {/* Header */}
      <div className="border-b border-zinc-800/80 pb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold text-purple-400 uppercase tracking-widest">
            <Settings className="w-4 h-4" />
            <span>Executive Administration</span>
          </div>
          <h1 className="text-3xl font-black text-white uppercase tracking-tight mt-1">
            Admin Panel
          </h1>
          <p className="text-xs text-zinc-400">
            Full control over recruitment pipelines, user management, audit logs, and website settings.
          </p>
        </div>

        {/* Tab Selector */}
        <div className="flex items-center gap-1.5 bg-zinc-900 p-1.5 rounded-2xl border border-zinc-800">
          <button
            onClick={() => setActiveTab('applications')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'applications'
                ? 'bg-purple-600 text-white shadow-md'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            Applications
          </button>
          <button
            onClick={() => setActiveTab('users')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'users'
                ? 'bg-purple-600 text-white shadow-md'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            User Roles
          </button>
          <button
            onClick={() => setActiveTab('audit')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'audit'
                ? 'bg-purple-600 text-white shadow-md'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            Audit Logs
          </button>
          <button
            onClick={() => setActiveTab('settings')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'settings'
                ? 'bg-purple-600 text-white shadow-md'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            Settings
          </button>
        </div>
      </div>

      {actionError && (
        <div className="p-3 bg-red-950/80 border border-red-800 rounded-xl text-red-200 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
          <span>{actionError}</span>
        </div>
      )}

      {/* SEARCH BAR */}
      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Search by name, email, discord, UID..."
          className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl py-3 pl-11 pr-4 text-xs text-white placeholder-zinc-500 outline-none focus:border-purple-500"
        />
      </div>

      {/* TAB 1: APPLICATIONS */}
      {activeTab === 'applications' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-extrabold text-white uppercase tracking-wider">
              Applications ({filteredApplications.length})
            </h3>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-1.5 text-xs text-white outline-none"
            >
              <option value="All">All Active Statuses</option>
              <option value="Pending">Pending</option>
              <option value="Under Review">Under Review</option>
              <option value="Accepted">Accepted</option>
            </select>
          </div>

          <div className="grid grid-cols-1 gap-4">
            {filteredApplications.map((app) => {
              const isAnimatingThis = animatingDecision?.id === app.id;
              return (
                <motion.div
                  key={app.id}
                  layout
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-zinc-950 border border-zinc-800/90 rounded-2xl p-6 space-y-4 hover:border-zinc-700 transition-colors relative overflow-hidden shadow-xl"
                >
                  <AnimatePresence>
                    {isAnimatingThis && animatingDecision && (
                      <ApplicationActionAnimation
                        status={animatingDecision.status}
                        applicantName={animatingDecision.name}
                        position={animatingDecision.position}
                      />
                    )}
                  </AnimatePresence>

                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-zinc-900 pb-3">
                    <div>
                      <div className="text-[10px] font-bold text-zinc-500">ID: {app.id}</div>
                      <h4 className="text-lg font-black text-white">{app.applicantName}</h4>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="px-3 py-1 bg-zinc-900 border border-zinc-800 rounded-xl text-xs font-bold text-orange-400">
                        {app.category}
                      </span>
                      <span className="px-3 py-1 bg-purple-950/80 border border-purple-800 rounded-xl text-xs font-bold text-purple-300 uppercase">
                        {app.status}
                      </span>
                    </div>
                  </div>

                  <div className="space-y-4 text-xs">
                    {QUESTIONS[app.category].map((q, i) => (
                      <div key={i} className="bg-zinc-900/50 p-4 rounded-xl border border-zinc-800/50">
                        <strong className="text-orange-400 block mb-1 uppercase">{q}</strong>
                        <p className="text-zinc-300">{app.answers[i.toString()] || 'No answer provided.'}</p>
                      </div>
                    ))}
                  </div>

                  {/* Admin Actions */}
                  <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-3">
                    <input
                      type="text"
                      placeholder="Optional decision note..."
                      onChange={(e) => setAdminNote(e.target.value)}
                      className="w-full sm:w-1/2 bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-1.5 text-xs text-white outline-none"
                    />
                    <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                      <motion.button
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        disabled={processingId === app.id}
                        onClick={() => handleDecision(app.id!, 'Under Review')}
                        className="px-3 py-1.5 bg-indigo-950 hover:bg-indigo-900 text-indigo-300 border border-indigo-800 text-xs font-bold rounded-xl disabled:opacity-50"
                      >
                        Under Review
                      </motion.button>
                      <motion.button
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        disabled={processingId === app.id}
                        onClick={() => handleDecision(app.id!, 'Accepted')}
                        className="px-3.5 py-1.5 bg-emerald-950 hover:bg-emerald-900 text-emerald-300 border border-emerald-800 text-xs font-bold rounded-xl shadow-md disabled:opacity-50"
                      >
                        {processingId === app.id ? 'Saving...' : 'Accept'}
                      </motion.button>
                      <motion.button
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        disabled={processingId === app.id}
                        onClick={() => handleDecision(app.id!, 'Rejected')}
                        className="px-3.5 py-1.5 bg-red-950 hover:bg-red-900 text-red-300 border border-red-800 text-xs font-bold rounded-xl shadow-md disabled:opacity-50"
                      >
                        {processingId === app.id ? 'Saving...' : 'Reject'}
                      </motion.button>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 2: USERS & ROLES */}
      {activeTab === 'users' && (
        <div className="space-y-4">
          <h3 className="text-sm font-extrabold text-white uppercase tracking-wider">
            User Account & Role Management ({filteredUsers.length})
          </h3>

          <div className="space-y-3">
            {filteredUsers.map((u) => (
              <div
                key={u.uid}
                className="bg-zinc-950 border border-zinc-800/90 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-extrabold text-white">{u.name}</span>
                    <span className="text-[10px] font-mono text-zinc-500">({u.uid})</span>
                    {u.isSuspended && (
                      <span className="text-[10px] bg-red-950 text-red-400 border border-red-800 px-2 py-0.5 rounded-full font-bold">
                        SUSPENDED
                      </span>
                    )}
                  </div>
                  <div className="text-xs text-zinc-400">{u.email}</div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs text-zinc-500 font-semibold">Role:</span>
                    <select
                      value={u.role}
                      onChange={(e) => handleRoleChange(u.uid, e.target.value as UserRole)}
                      disabled={u.role === 'OWNER'}
                      className="bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-1.5 text-xs text-orange-400 font-bold outline-none disabled:opacity-50"
                    >
                      <option value="USER">USER</option>
                      <option value="STAFF">STAFF</option>
                      <option value="MOD">MOD</option>
                      <option value="ADMIN">ADMIN</option>
                      {u.role === 'OWNER' && <option value="OWNER">OWNER</option>}
                    </select>
                  </div>

                  {u.role !== 'OWNER' && (
                    <button
                      onClick={() => handleToggleSuspend(u.uid, u.isSuspended)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-colors ${
                        u.isSuspended
                          ? 'bg-emerald-950 text-emerald-300 border-emerald-800 hover:bg-emerald-900'
                          : 'bg-red-950 text-red-300 border-red-800 hover:bg-red-900'
                      }`}
                    >
                      {u.isSuspended ? 'Activate' : 'Suspend'}
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: AUDIT LOGS */}
      {activeTab === 'audit' && (
        <div className="space-y-4">
          <h3 className="text-sm font-extrabold text-white uppercase tracking-wider">
            System Audit Log Feed ({auditLogs.length})
          </h3>

          <div className="space-y-2 max-h-[600px] overflow-y-auto">
            {auditLogs.map((log) => (
              <div
                key={log.id}
                className="bg-zinc-950 border border-zinc-800/80 rounded-2xl p-4 text-xs space-y-1"
              >
                <div className="flex items-center justify-between text-zinc-400">
                  <span className="font-bold text-white">{log.actorName} ({log.actorRole})</span>
                  <span>{new Date(log.timestamp).toLocaleString()}</span>
                </div>
                <div className="text-orange-400 font-bold">Action: {log.action}</div>
                <div className="text-zinc-500 font-mono text-[11px]">
                  Target: {log.targetResource} {log.targetUid && `(${log.targetUid})`}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 4: SYSTEM SETTINGS */}
      {activeTab === 'settings' && (
        <div className="bg-zinc-950 border border-zinc-800/90 rounded-3xl p-6 sm:p-8 space-y-6 max-w-2xl">
          <h3 className="text-base font-extrabold text-white uppercase tracking-wider">
            Website & Recruitment Settings
          </h3>

          <div className="space-y-4 text-xs">
            <div className="flex items-center justify-between p-4 bg-zinc-900/80 rounded-2xl border border-zinc-800">
              <div>
                <strong className="text-white block text-sm">Applications Open</strong>
                <span className="text-zinc-400">Toggle whether users can submit new staff applications.</span>
              </div>
              <input
                type="checkbox"
                checked={appsOpen}
                onChange={(e) => setAppsOpen(e.target.checked)}
                className="w-5 h-5 accent-purple-600 rounded cursor-pointer"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-zinc-300 mb-1.5 uppercase tracking-wider">
                Public Announcement Banner Text
              </label>
              <textarea
                value={announcementText}
                onChange={(e) => setAnnouncementText(e.target.value)}
                rows={3}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-3 text-xs text-white outline-none"
              />
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={handleSaveSettings}
                className="px-6 py-2.5 bg-purple-600 hover:bg-purple-500 text-white font-extrabold text-xs uppercase tracking-wider rounded-xl transition-all shadow-md"
              >
                Save Settings
              </button>
            </div>
          </div>
        </div>
      )}
    </motion.div>
  );
};
