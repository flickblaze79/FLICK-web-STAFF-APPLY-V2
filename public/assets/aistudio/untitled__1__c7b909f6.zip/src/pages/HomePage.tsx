import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { collection, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';
import {
  Shield,
  Users,
  Award,
  CheckCircle2,
  ArrowRight,
  MessageSquare,
  Sparkles,
  FileCheck,
  UserCheck,
} from 'lucide-react';

interface HomePageProps {
  onNavigate: (page: string, category?: string) => void;
  onOpenAuth: () => void;
  isAuthenticated: boolean;
}

export const HomePage: React.FC<HomePageProps> = ({ onNavigate, onOpenAuth, isAuthenticated }) => {
  const [stats, setStats] = useState({
    totalApplications: 0,
    acceptedStaff: 0,
    pendingReviews: 0,
    activePositions: 5,
  });
  const [loadingStats, setLoadingStats] = useState(true);

  const DISCORD_URL = 'https://discord.gg/BRDwvqbFf';

  useEffect(() => {
    async function loadRealStats() {
      try {
        const appsSnap = await getDocs(collection(db, 'applications'));
        const total = appsSnap.size;
        let accepted = 0;
        let pending = 0;

        appsSnap.forEach((doc) => {
          const data = doc.data();
          if (data.status === 'Accepted') accepted++;
          if (data.status === 'Pending' || data.status === 'Under Review') pending++;
        });

        setStats({
          totalApplications: total,
          acceptedStaff: accepted,
          pendingReviews: pending,
          activePositions: 5,
        });
      } catch (err) {
        console.warn('Stats fetch notice:', err);
      } finally {
        setLoadingStats(false);
      }
    }

    loadRealStats();
  }, []);

  const positions = [
    {
      title: 'Helper',
      color: 'from-blue-500 to-indigo-600',
      description: 'Assist community members, answer support questions, and guide new users.',
      requirements: ['Min. Age: 14+', 'Active on Discord', 'Friendly & Patient Attitude'],
    },
    {
      title: 'Staff',
      color: 'from-red-500 to-rose-600',
      description: 'General staff operations, event organization, ticket management, and member support.',
      requirements: ['Proven Track Record', 'Excellent Communication', 'Team Player'],
    },
    {
      title: 'Developer',
      color: 'from-violet-500 to-purple-600',
      description: 'Build and maintain our web applications, optimize systems, and implement new features.',
      requirements: ['Programming Experience', 'GitHub Portfolio', 'Problem-Solving Mindset'],
    },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="space-y-16 py-6"
    >
      {/* HERO SECTION */}
      <section className="relative overflow-hidden rounded-3xl bg-panel border border-secondary/20 p-8 sm:p-12 lg:p-16 text-center shadow-2xl">
        {/* Glow Effects */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[300px] bg-gradient-to-b from-primary/20 via-secondary/10 to-transparent blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-3xl mx-auto space-y-6">
          {/* Official Emblem Logo */}
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
            className="flex justify-center"
          >
            <div className="relative group">
              {/* Subtle back ambient glow */}
              <div className="absolute -inset-2 bg-gradient-to-b from-primary/30 via-secondary/20 to-transparent rounded-full blur-2xl opacity-70 group-hover:opacity-100 transition duration-500 pointer-events-none" />
              {/* Outer chassis frame */}
              <div className="relative w-32 h-32 sm:w-40 sm:h-40 rounded-full p-2 bg-gradient-to-b from-panel to-canvas border border-secondary/40 shadow-2xl shadow-black/90 flex items-center justify-center">
                <img
                  src="/assets/aistudio/file_000000006914821196df3f2d2e60b066_3eb967aa.png"
                  alt="flick staff apply Crest"
                  className="w-full h-full object-contain drop-shadow-[0_10px_20px_rgba(8,123,255,0.4)]"
                />
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.1, duration: 0.4 }}
            className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-primary/20 border border-primary/30 text-secondary text-xs font-bold uppercase tracking-widest shadow-inner"
          >
            <Sparkles className="w-3.5 h-3.5 text-secondary" />
            <span>Official Recruitment Portal</span>
          </motion.div>

          <motion.h1
            initial={{ y: 15, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2, duration: 0.5 }}
            className="text-4xl sm:text-6xl font-black tracking-tight text-main uppercase leading-tight"
          >
            FLICK <span className="bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">STAFF APPLY</span>
          </motion.h1>

          <motion.p
            initial={{ y: 15, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.3, duration: 0.5 }}
            className="text-lg sm:text-xl text-muted font-medium leading-relaxed"
          >
            Join the team. Help the community. Make an impact.
          </motion.p>

          <motion.div
            initial={{ y: 15, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.4, duration: 0.5 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4"
          >
            <motion.button
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              onClick={() => {
                if (!isAuthenticated) {
                  onOpenAuth();
                } else {
                  onNavigate('apply');
                }
              }}
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-8 py-4 bg-gradient-to-r from-primary to-secondary hover:from-blue-600 hover:to-cyan-500 text-white font-extrabold text-base rounded-2xl shadow-xl shadow-primary/20 transition-all"
            >
              <span>Apply Now</span>
              <ArrowRight className="w-5 h-5" />
            </motion.button>

            <motion.a
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              href={DISCORD_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-8 py-4 bg-panel hover:bg-secondary/10 text-secondary border border-secondary/50 font-bold text-base rounded-2xl transition-all"
            >
              <MessageSquare className="w-5 h-5 text-secondary" />
              <span>Join Discord</span>
            </motion.a>
          </motion.div>
        </div>

        {/* REAL STATISTICS DISPLAY */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mt-12 pt-8 border-t border-secondary/20 text-left max-w-4xl mx-auto">
          <motion.div whileHover={{ y: -3 }} className="bg-panel border border-secondary/20 p-4 rounded-2xl">
            <div className="text-muted text-xs font-semibold uppercase tracking-wider">Total Applications</div>
            <div className="text-2xl sm:text-3xl font-black text-main mt-1">
              {loadingStats ? '...' : stats.totalApplications}
            </div>
          </motion.div>
          <motion.div whileHover={{ y: -3 }} className="bg-panel border border-secondary/20 p-4 rounded-2xl">
            <div className="text-muted text-xs font-semibold uppercase tracking-wider">Active Staff</div>
            <div className="text-2xl sm:text-3xl font-black text-secondary mt-1">
              {loadingStats ? '...' : stats.acceptedStaff}
            </div>
          </motion.div>
          <motion.div whileHover={{ y: -3 }} className="bg-panel border border-secondary/20 p-4 rounded-2xl">
            <div className="text-muted text-xs font-semibold uppercase tracking-wider">Pending Reviews</div>
            <div className="text-2xl sm:text-3xl font-black text-secondary mt-1">
              {loadingStats ? '...' : stats.pendingReviews}
            </div>
          </motion.div>
          <motion.div whileHover={{ y: -3 }} className="bg-panel border border-secondary/20 p-4 rounded-2xl">
            <div className="text-muted text-xs font-semibold uppercase tracking-wider">Open Positions</div>
            <div className="text-2xl sm:text-3xl font-black text-secondary mt-1">
              {stats.activePositions}
            </div>
          </motion.div>
        </div>
      </section>

      {/* ABOUT STAFF TEAM */}
      <section className="space-y-6">
        <div className="text-center space-y-2 max-w-xl mx-auto">
          <h2 className="text-2xl sm:text-3xl font-extrabold text-main">About The Staff Team</h2>
          <p className="text-xs sm:text-sm text-muted">
            Our staff team works around the clock to provide a safe, respectful, and engaging environment.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <motion.div whileHover={{ y: -4 }} className="bg-panel border border-secondary/20 p-6 rounded-2xl space-y-3">
            <div className="w-10 h-10 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center text-secondary">
              <Shield className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-bold text-main">Community Protection</h3>
            <p className="text-xs text-muted leading-relaxed">
              Maintain order, enforce community rules fairly, and prevent harassment or malicious behavior across all platforms.
            </p>
          </motion.div>

          <motion.div whileHover={{ y: -4 }} className="bg-panel border border-secondary/20 p-6 rounded-2xl space-y-3">
            <div className="w-10 h-10 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center text-secondary">
              <Users className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-bold text-main">Member Support</h3>
            <p className="text-xs text-muted leading-relaxed">
              Help new players get started, answer tickets, resolve disputes, and host community events.
            </p>
          </motion.div>

          <motion.div whileHover={{ y: -4 }} className="bg-panel border border-secondary/20 p-6 rounded-2xl space-y-3">
            <div className="w-10 h-10 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center text-secondary">
              <Award className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-bold text-main">Growth & Leadership</h3>
            <p className="text-xs text-muted leading-relaxed">
              Gain real team leadership experience, unlock internal ranks, and build your moderation portfolio.
            </p>
          </motion.div>
        </div>
      </section>

      {/* AVAILABLE POSITIONS */}
      <section className="space-y-6">
        <div className="text-center space-y-2 max-w-xl mx-auto">
          <h2 className="text-2xl sm:text-3xl font-extrabold text-main">Available Positions</h2>
          <p className="text-xs sm:text-sm text-muted">
            Select a position that best matches your skills and experience level.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {positions.map((pos) => (
            <motion.div
              key={pos.title}
              whileHover={{ y: -5 }}
              className="bg-panel border border-secondary/20 p-6 rounded-2xl flex flex-col justify-between space-y-4 hover:border-secondary/40 transition-colors"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className={`text-xs font-black px-3 py-1 rounded-full bg-gradient-to-r ${pos.color} text-white uppercase tracking-wider`}>
                    {pos.title}
                  </span>
                  <span className="text-[10px] font-bold text-secondary bg-secondary/10 border border-secondary/20 px-2 py-0.5 rounded-md">
                    Open
                  </span>
                </div>
                <p className="text-xs text-muted leading-relaxed">{pos.description}</p>
                <div className="space-y-1.5 pt-2">
                  <div className="text-[11px] font-bold text-main uppercase tracking-wider">Key Prerequisites:</div>
                  {pos.requirements.map((req, i) => (
                    <div key={i} className="flex items-center gap-2 text-xs text-muted">
                      <CheckCircle2 className="w-3.5 h-3.5 text-secondary shrink-0" />
                      <span>{req}</span>
                    </div>
                  ))}
                </div>
              </div>

              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => {
                  if (!isAuthenticated) {
                    onOpenAuth();
                  } else {
                    onNavigate('apply', `${pos.title} Application`);
                  }
                }}
                className="w-full py-2.5 bg-panel hover:bg-secondary/10 text-main font-bold text-xs rounded-xl border border-secondary/20 transition-all text-center"
              >
                Apply for {pos.title}
              </motion.button>
            </motion.div>
          ))}
        </div>
      </section>

      {/* REQUIREMENTS & PROCESS */}
      <section className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <motion.div whileHover={{ y: -3 }} className="bg-panel border border-secondary/20 p-6 sm:p-8 rounded-3xl space-y-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-primary/10 border border-primary/20 text-secondary">
              <FileCheck className="w-5 h-5" />
            </div>
            <h3 className="text-xl font-extrabold text-main">General Staff Requirements</h3>
          </div>
          <ul className="space-y-3 text-xs text-muted">
            <li className="flex items-start gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-secondary shrink-0 mt-0.5" />
              <span>Must be an active member of the FLICK Discord community with a clean disciplinary record.</span>
            </li>
            <li className="flex items-start gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-secondary shrink-0 mt-0.5" />
              <span>Possess strong command of written English and clear communication habits.</span>
            </li>
            <li className="flex items-start gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-secondary shrink-0 mt-0.5" />
              <span>Demonstrate emotional maturity, impartiality, and discretion under pressure.</span>
            </li>
            <li className="flex items-start gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-secondary shrink-0 mt-0.5" />
              <span>Have a working Discord account with Two-Factor Authentication (2FA) enabled.</span>
            </li>
          </ul>
        </motion.div>

        <motion.div whileHover={{ y: -3 }} className="bg-panel border border-secondary/20 p-6 sm:p-8 rounded-3xl space-y-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-primary/10 border border-primary/20 text-secondary">
              <UserCheck className="w-5 h-5" />
            </div>
            <h3 className="text-xl font-extrabold text-main">Application Process</h3>
          </div>
          <ol className="space-y-3 text-xs text-muted">
            <li className="flex items-start gap-3">
              <span className="w-6 h-6 rounded-full bg-primary/20 border border-primary/30 text-secondary font-bold flex items-center justify-center shrink-0">
                1
              </span>
              <div>
                <strong className="text-main block">Submit Application</strong>
                Fill out the comprehensive form with real information and detailed answers.
              </div>
            </li>
            <li className="flex items-start gap-3">
              <span className="w-6 h-6 rounded-full bg-primary/20 border border-primary/30 text-secondary font-bold flex items-center justify-center shrink-0">
                2
              </span>
              <div>
                <strong className="text-main block">Review & Assessment</strong>
                Our Moderation & Admin team evaluates your answers and background checks.
              </div>
            </li>
            <li className="flex items-start gap-3">
              <span className="w-6 h-6 rounded-full bg-primary/20 border border-primary/30 text-secondary font-bold flex items-center justify-center shrink-0">
                3
              </span>
              <div>
                <strong className="text-main block">Status Notification</strong>
                Track your live application status on the portal and receive direct decision feedback.
              </div>
            </li>
          </ol>
        </motion.div>
      </section>
    </motion.div>
  );
};
