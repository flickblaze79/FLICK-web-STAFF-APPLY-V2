import React, { useEffect, useState } from 'react';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from '../context/AuthContext';
import { StaffApplication, QUESTIONS } from '../types';
import { ClipboardList, Clock, CheckCircle2, XCircle, Search, ShieldCheck, FileText } from 'lucide-react';

interface ApplicationStatusPageProps {
  onNavigate: (page: string) => void;
  onOpenAuth: () => void;
}

export const ApplicationStatusPage: React.FC<ApplicationStatusPageProps> = ({ onNavigate, onOpenAuth }) => {
  const { currentUser } = useAuth();
  const [applications, setApplications] = useState<StaffApplication[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadUserApplications() {
      if (!currentUser) {
        setLoading(false);
        return;
      }

      try {
        const q = query(
          collection(db, 'applications'),
          where('applicantUid', '==', currentUser.uid)
        );
        const snap = await getDocs(q);
        const list: StaffApplication[] = [];
        snap.forEach((doc) => {
          list.push({ ...doc.data(), id: doc.id } as StaffApplication);
        });

        // Sort by newest first
        list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        setApplications(list);
      } catch (err) {
        console.error('Error fetching application status:', err);
      } finally {
        setLoading(false);
      }
    }

    loadUserApplications();
  }, [currentUser]);

  if (!currentUser) {
    return (
      <div className="max-w-2xl mx-auto py-16 px-4 text-center space-y-6 bg-zinc-950 border border-zinc-800 rounded-3xl p-8 mt-10">
        <div className="w-16 h-16 mx-auto rounded-2xl bg-orange-950/80 border border-orange-800/60 flex items-center justify-center text-orange-400">
          <ShieldCheck className="w-8 h-8" />
        </div>
        <h2 className="text-2xl font-black text-white">Sign In Required</h2>
        <p className="text-xs sm:text-sm text-zinc-400 max-w-md mx-auto">
          Please sign in to view your application history and live review updates.
        </p>
        <button
          onClick={onOpenAuth}
          className="px-8 py-3 bg-gradient-to-r from-red-600 to-orange-600 text-white font-bold text-sm rounded-xl hover:from-red-500 hover:to-orange-500 transition-all shadow-lg"
        >
          Sign In / Register
        </button>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto py-20 text-center text-zinc-400 text-sm">
        Loading your application history...
      </div>
    );
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'Accepted':
        return (
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-700/80 text-emerald-400 text-xs font-bold uppercase tracking-wider">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Accepted</span>
          </div>
        );
      case 'Rejected':
        return (
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-950/80 border border-red-700/80 text-red-400 text-xs font-bold uppercase tracking-wider">
            <XCircle className="w-3.5 h-3.5" />
            <span>Rejected</span>
          </div>
        );
      case 'Under Review':
        return (
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-950/80 border border-indigo-700/80 text-indigo-400 text-xs font-bold uppercase tracking-wider">
            <Search className="w-3.5 h-3.5" />
            <span>Under Review</span>
          </div>
        );
      default:
        return (
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-950/80 border border-amber-700/80 text-amber-400 text-xs font-bold uppercase tracking-wider">
            <Clock className="w-3.5 h-3.5" />
            <span>Pending</span>
          </div>
        );
    }
  };

  return (
    <div className="max-w-4xl mx-auto py-8 px-4 space-y-8">
      <div className="space-y-2 border-b border-zinc-800/80 pb-6">
        <span className="text-xs font-bold text-orange-400 uppercase tracking-widest">
          Live Tracking
        </span>
        <h1 className="text-3xl font-black text-white uppercase tracking-tight">
          Application Status
        </h1>
        <p className="text-xs sm:text-sm text-zinc-400">
          View real-time evaluation status and reviewer feedback for your submitted staff applications.
        </p>
      </div>

      {applications.length === 0 ? (
        <div className="bg-zinc-950 border border-zinc-800/90 rounded-3xl p-12 text-center space-y-4">
          <div className="w-16 h-16 mx-auto rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center justify-center text-zinc-500">
            <ClipboardList className="w-8 h-8" />
          </div>
          <h3 className="text-lg font-bold text-white">No application found.</h3>
          <p className="text-xs text-zinc-400 max-w-sm mx-auto">
            You have not submitted any staff applications yet. Click below to submit your application today.
          </p>
          <button
            onClick={() => onNavigate('apply')}
            className="inline-flex items-center gap-2 px-6 py-2.5 bg-gradient-to-r from-red-600 to-orange-600 text-white text-xs font-bold rounded-xl shadow-md hover:from-red-500 hover:to-orange-500 transition-all"
          >
            <FileText className="w-4 h-4" />
            <span>Apply Now</span>
          </button>
        </div>
      ) : (
        <div className="space-y-6">
          {applications.map((app) => (
            <div
              key={app.id}
              className="bg-zinc-950 border border-zinc-800/90 rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-zinc-900 pb-4">
                <div>
                  <div className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">
                    Application ID: <span className="font-mono text-zinc-300">{app.id}</span>
                  </div>
                  <h3 className="text-xl font-extrabold text-white mt-1">
                    Category: <span className="text-orange-400">{app.category}</span>
                  </h3>
                </div>
                <div>{getStatusBadge(app.status)}</div>
              </div>

              {/* Answers */}
              <div className="space-y-4 text-xs">
                {QUESTIONS[app.category].map((q, i) => (
                  <div key={i} className="bg-zinc-900/60 p-4 rounded-2xl">
                    <span className="font-bold text-orange-400 block mb-1 uppercase tracking-wider">{q}</span>
                    <p className="text-zinc-300 leading-relaxed">{app.answers[i.toString()] || 'No answer provided.'}</p>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
