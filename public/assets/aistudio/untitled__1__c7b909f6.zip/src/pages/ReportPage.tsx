import React, { useEffect, useState } from 'react';
import { collection, addDoc, query, where, getDocs } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { useAuth } from '../context/AuthContext';
import { UserReport } from '../types';
import { logAuditEvent } from '../lib/auditLogger';
import { AlertTriangle, Send, CheckCircle2, Clock, ShieldCheck, MessageSquare } from 'lucide-react';

interface ReportPageProps {
  onOpenAuth: () => void;
}

export const ReportPage: React.FC<ReportPageProps> = ({ onOpenAuth }) => {
  const { currentUser, userProfile } = useAuth();

  const [reportType, setReportType] = useState('Rules Violation');
  const [subject, setSubject] = useState('');
  const [description, setDescription] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [myReports, setMyReports] = useState<UserReport[]>([]);
  const [loadingReports, setLoadingReports] = useState(true);

  useEffect(() => {
    async function loadMyReports() {
      if (!currentUser) {
        setLoadingReports(false);
        return;
      }
      try {
        const q = query(
          collection(db, 'reports'),
          where('authorUid', '==', currentUser.uid)
        );
        const snap = await getDocs(q);
        const list: UserReport[] = [];
        snap.forEach((doc) => {
          list.push({ ...doc.data(), id: doc.id } as UserReport);
        });
        list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        setMyReports(list);
      } catch (err) {
        console.warn('Error loading reports:', err);
      } finally {
        setLoadingReports(false);
      }
    }

    loadMyReports();
  }, [currentUser, success]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!currentUser) {
      onOpenAuth();
      return;
    }

    if (!subject.trim() || !description.trim()) {
      setError('Please complete all required fields.');
      return;
    }

    setSubmitting(true);

    try {
      const newReport: Omit<UserReport, 'id'> = {
        authorUid: currentUser.uid,
        authorName: userProfile?.name || 'Anonymous',
        authorEmail: currentUser.email || '',
        reportType,
        subject: subject.trim(),
        description: description.trim(),
        status: 'Open',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      const docRef = await addDoc(collection(db, 'reports'), newReport);

      await logAuditEvent({
        action: 'REPORT_SUBMITTED',
        actorUid: currentUser.uid,
        actorName: userProfile?.name || 'User',
        actorEmail: currentUser.email || '',
        actorRole: userProfile?.role || 'USER',
        targetResource: 'reports',
        targetUid: docRef.id,
        metadata: { reportType, subject },
      });

      setSuccess(true);
      setSubject('');
      setDescription('');
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'reports');
    } finally {
      setSubmitting(false);
    }
  };

  if (!currentUser) {
    return (
      <div className="max-w-2xl mx-auto py-16 px-4 text-center space-y-6 bg-zinc-950 border border-zinc-800 rounded-3xl p-8 mt-10">
        <div className="w-16 h-16 mx-auto rounded-2xl bg-orange-950/80 border border-orange-800/60 flex items-center justify-center text-orange-400">
          <ShieldCheck className="w-8 h-8" />
        </div>
        <h2 className="text-2xl font-black text-white">Sign In Required</h2>
        <p className="text-xs sm:text-sm text-zinc-400 max-w-md mx-auto">
          You must be signed in to submit a community report to our moderation team.
        </p>
        <button
          onClick={onOpenAuth}
          className="px-8 py-3 bg-gradient-to-r from-red-600 to-orange-600 text-white font-bold text-sm rounded-xl hover:from-red-500 hover:to-orange-500 transition-all shadow-lg"
        >
          Sign In / Register
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto py-8 px-4 space-y-12">
      <div className="border-b border-zinc-800/80 pb-6">
        <span className="text-xs font-bold text-orange-400 uppercase tracking-widest">
          Community Safety
        </span>
        <h1 className="text-3xl font-black text-white uppercase tracking-tight">
          Submit Report
        </h1>
        <p className="text-xs sm:text-sm text-zinc-400 mt-1">
          Report rule violations, staff misconduct, technical bugs, or player disputes directly to FLICK Moderation.
        </p>
      </div>

      {/* FORM SECTION */}
      <div className="bg-zinc-950 border border-zinc-800/90 rounded-3xl p-6 sm:p-8 space-y-6 shadow-2xl">
        <h2 className="text-lg font-bold text-white flex items-center gap-2">
          <AlertTriangle className="w-5 h-5 text-orange-400" />
          <span>New Incident Report</span>
        </h2>

        {success && (
          <div className="p-4 bg-emerald-950/60 border border-emerald-800/60 rounded-2xl text-emerald-200 text-xs flex items-center gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            <span>Report submitted successfully! Our moderators will review it shortly.</span>
          </div>
        )}

        {error && (
          <div className="p-4 bg-red-950/60 border border-red-800/60 rounded-2xl text-red-200 text-xs flex items-center gap-3">
            <AlertTriangle className="w-5 h-5 text-red-400 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-zinc-300 mb-1.5 uppercase tracking-wider">
                Report Type
              </label>
              <select
                value={reportType}
                onChange={(e) => setReportType(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2.5 px-4 text-sm text-white outline-none focus:border-orange-500"
              >
                <option value="Rules Violation">Rules Violation</option>
                <option value="Player Harassment">Player Harassment</option>
                <option value="Staff Misconduct">Staff Misconduct</option>
                <option value="Bug / Exploit">Bug / Exploit</option>
                <option value="Other">Other</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-zinc-300 mb-1.5 uppercase tracking-wider">
                Subject
              </label>
              <input
                type="text"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="Brief title of the incident"
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2.5 px-4 text-sm text-white outline-none focus:border-orange-500"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-zinc-300 mb-1.5 uppercase tracking-wider">
              Detailed Description
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Provide evidence, timestamps, Discord IDs, or detailed description of what occurred."
              rows={5}
              className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-3 text-sm text-white outline-none focus:border-orange-500"
              required
            />
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              disabled={submitting}
              className="px-6 py-3 bg-gradient-to-r from-red-600 to-orange-600 hover:from-red-500 hover:to-orange-500 text-white font-extrabold text-xs uppercase tracking-wider rounded-xl transition-all shadow-md disabled:opacity-50 flex items-center gap-2"
            >
              <Send className="w-4 h-4" />
              <span>{submitting ? 'Submitting...' : 'Submit Report'}</span>
            </button>
          </div>
        </form>
      </div>

      {/* MY REPORTS SECTION */}
      <div className="space-y-4">
        <h2 className="text-xl font-bold text-white flex items-center gap-2">
          <MessageSquare className="w-5 h-5 text-orange-400" />
          <span>My Submitted Reports</span>
        </h2>

        {loadingReports ? (
          <div className="text-xs text-zinc-400">Loading reports...</div>
        ) : myReports.length === 0 ? (
          <div className="bg-zinc-950 border border-zinc-800/80 rounded-2xl p-6 text-center text-xs text-zinc-500">
            No report history found.
          </div>
        ) : (
          <div className="space-y-4">
            {myReports.map((rep) => (
              <div key={rep.id} className="bg-zinc-950 border border-zinc-800/90 rounded-2xl p-5 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-extrabold text-white">{rep.subject}</span>
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-zinc-800 text-orange-400 border border-zinc-700 uppercase">
                    {rep.status}
                  </span>
                </div>
                <div className="text-[11px] text-zinc-400">{rep.reportType} • {new Date(rep.createdAt).toLocaleDateString()}</div>
                <p className="text-xs text-zinc-300 leading-relaxed bg-zinc-900/60 p-3 rounded-xl border border-zinc-800/60">
                  {rep.description}
                </p>
                {rep.resolutionNotes && (
                  <div className="text-xs text-emerald-300 bg-emerald-950/40 p-2.5 rounded-xl border border-emerald-900/40">
                    <strong>Moderation Response:</strong> {rep.resolutionNotes}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
