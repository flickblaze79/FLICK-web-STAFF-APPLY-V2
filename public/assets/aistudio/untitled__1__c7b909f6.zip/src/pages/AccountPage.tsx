import React, { useState } from 'react';
import { sendPasswordResetEmail } from 'firebase/auth';
import { auth } from '../lib/firebase';
import { useAuth } from '../context/AuthContext';
import { User, Mail, Shield, Calendar, Key, CheckCircle2, AlertCircle, LogOut, Edit2, Save } from 'lucide-react';

export const AccountPage: React.FC = () => {
  const { currentUser, userProfile, logout, updateDisplayName } = useAuth();

  const [isEditingName, setIsEditingName] = useState(false);
  const [newDisplayName, setNewDisplayName] = useState(userProfile?.name || '');
  const [savingName, setSavingName] = useState(false);

  const [resetMessage, setResetMessage] = useState<string | null>(null);
  const [resetError, setResetError] = useState<string | null>(null);
  const [sendingReset, setSendingReset] = useState(false);

  if (!currentUser || !userProfile) {
    return (
      <div className="max-w-md mx-auto py-20 text-center text-zinc-400 text-sm">
        Please sign in to view your account details.
      </div>
    );
  }

  const handleSaveName = async () => {
    if (!newDisplayName.trim()) return;
    setSavingName(true);
    try {
      await updateDisplayName(newDisplayName.trim());
      setIsEditingName(false);
    } catch (err) {
      console.error('Error updating name:', err);
    } finally {
      setSavingName(false);
    }
  };

  const handlePasswordReset = async () => {
    setResetMessage(null);
    setResetError(null);
    setSendingReset(true);
    try {
      if (currentUser.email) {
        await sendPasswordResetEmail(auth, currentUser.email);
        setResetMessage('Password reset instructions sent to your email.');
      }
    } catch (err: any) {
      setResetError(err.message || 'Failed to send password reset email.');
    } finally {
      setSendingReset(false);
    }
  };

  const roleColors: Record<string, string> = {
    USER: 'bg-zinc-800 text-zinc-300 border-zinc-700',
    STAFF: 'bg-blue-950 text-blue-400 border-blue-800',
    MOD: 'bg-emerald-950 text-emerald-400 border-emerald-800',
    ADMIN: 'bg-purple-950 text-purple-400 border-purple-800',
    OWNER: 'bg-amber-950 text-amber-400 border-amber-800',
  };

  return (
    <div className="max-w-3xl mx-auto py-8 px-4 space-y-8">
      <div className="border-b border-zinc-800/80 pb-6">
        <span className="text-xs font-bold text-orange-400 uppercase tracking-widest">
          User Settings
        </span>
        <h1 className="text-3xl font-black text-white uppercase tracking-tight">
          My Account
        </h1>
      </div>

      <div className="bg-zinc-950 border border-zinc-800/90 rounded-3xl p-6 sm:p-8 space-y-8 shadow-2xl">
        {/* Profile Header */}
        <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6 border-b border-zinc-900 pb-8">
          <div className="w-20 h-20 rounded-3xl bg-gradient-to-br from-red-600 to-orange-600 flex items-center justify-center font-black text-3xl text-white shadow-xl">
            {userProfile.name?.charAt(0).toUpperCase() || 'U'}
          </div>

          <div className="flex-1 text-center sm:text-left space-y-2">
            <div className="flex flex-col sm:flex-row items-center gap-3">
              {isEditingName ? (
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={newDisplayName}
                    onChange={(e) => setNewDisplayName(e.target.value)}
                    className="bg-zinc-900 border border-zinc-700 rounded-xl px-3 py-1.5 text-sm font-bold text-white outline-none"
                  />
                  <button
                    onClick={handleSaveName}
                    disabled={savingName}
                    className="p-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl"
                  >
                    <Save className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <h2 className="text-2xl font-black text-white">{userProfile.name}</h2>
                  <button
                    onClick={() => {
                      setNewDisplayName(userProfile.name);
                      setIsEditingName(true);
                    }}
                    className="text-zinc-500 hover:text-zinc-300 p-1"
                    title="Edit Name"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                </div>
              )}

              <span
                className={`text-xs font-black uppercase px-3 py-1 rounded-full border ${
                  roleColors[userProfile.role] || roleColors.USER
                }`}
              >
                {userProfile.role}
              </span>
            </div>

            <p className="text-xs text-zinc-400 flex items-center justify-center sm:justify-start gap-1.5">
              <Mail className="w-3.5 h-3.5 text-zinc-500" />
              <span>{userProfile.email}</span>
            </p>
          </div>
        </div>

        {/* Account Details */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="bg-zinc-900/60 border border-zinc-800 p-4 rounded-2xl space-y-1">
            <div className="text-[10px] font-bold text-zinc-500 uppercase tracking-wider flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-orange-400" />
              <span>Account Creation Date</span>
            </div>
            <div className="text-sm font-bold text-zinc-200">
              {new Date(userProfile.createdAt || Date.now()).toLocaleDateString()}
            </div>
          </div>

          <div className="bg-zinc-900/60 border border-zinc-800 p-4 rounded-2xl space-y-1">
            <div className="text-[10px] font-bold text-zinc-500 uppercase tracking-wider flex items-center gap-1.5">
              <Key className="w-3.5 h-3.5 text-orange-400" />
              <span>Auth Provider</span>
            </div>
            <div className="text-sm font-bold text-zinc-200 uppercase">
              {userProfile.providerId || 'Email / Password'}
            </div>
          </div>
        </div>

        {/* Security & Password Reset */}
        <div className="space-y-3 pt-2">
          <h3 className="text-xs font-bold text-zinc-400 uppercase tracking-wider">
            Security & Password Reset
          </h3>

          {resetMessage && (
            <div className="p-3 bg-emerald-950/60 border border-emerald-800/60 rounded-xl text-emerald-200 text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{resetMessage}</span>
            </div>
          )}

          {resetError && (
            <div className="p-3 bg-red-950/60 border border-red-800/60 rounded-xl text-red-200 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
              <span>{resetError}</span>
            </div>
          )}

          <button
            onClick={handlePasswordReset}
            disabled={sendingReset}
            className="px-4 py-2.5 bg-zinc-900 hover:bg-zinc-800 text-zinc-200 border border-zinc-800 rounded-xl text-xs font-bold transition-all disabled:opacity-50"
          >
            {sendingReset ? 'Sending Reset Email...' : 'Send Password Reset Email'}
          </button>
        </div>

        {/* Logout */}
        <div className="pt-6 border-t border-zinc-900 flex justify-end">
          <button
            onClick={logout}
            className="flex items-center gap-2 px-6 py-2.5 bg-red-950/50 hover:bg-red-900/60 text-red-300 border border-red-800/60 font-bold text-xs rounded-xl transition-all"
          >
            <LogOut className="w-4 h-4" />
            <span>Sign Out</span>
          </button>
        </div>
      </div>
    </div>
  );
};
