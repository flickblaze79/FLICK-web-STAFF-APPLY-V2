import { collection, addDoc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from './firebase';
import { AuditLogEntry, UserRole } from '../types';

export async function logAuditEvent(params: {
  action: string;
  actorUid: string;
  actorName: string;
  actorEmail: string;
  actorRole: UserRole;
  targetResource: string;
  targetUid?: string;
  metadata?: Record<string, any>;
}) {
  const collectionPath = 'audit_logs';
  try {
    const entry: Omit<AuditLogEntry, 'id'> = {
      action: params.action,
      actorUid: params.actorUid,
      actorName: params.actorName || 'Unknown',
      actorEmail: params.actorEmail || 'Unknown',
      actorRole: params.actorRole || 'USER',
      targetResource: params.targetResource,
      targetUid: params.targetUid || '',
      timestamp: new Date().toISOString(),
      metadata: params.metadata || {},
    };
    await addDoc(collection(db, collectionPath), entry);
  } catch (err) {
    // Audit logging failure should log error gracefully
    console.warn('Audit logging failed:', err);
  }
}
