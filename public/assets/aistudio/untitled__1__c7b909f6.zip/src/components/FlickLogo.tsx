import React from 'react';

interface FlickLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl' | '2xl';
  showText?: boolean;
  className?: string;
}

export const FlickLogo: React.FC<FlickLogoProps> = ({ size = 'md', showText = true, className = '' }) => {
  const dimensions = {
    sm: { img: 'w-8 h-8', text: 'text-sm font-bold tracking-tight', sub: 'text-[9px]' },
    md: { img: 'w-10 h-10', text: 'text-base font-extrabold tracking-tight', sub: 'text-[10px]' },
    lg: { img: 'w-14 h-14', text: 'text-xl font-black tracking-tight', sub: 'text-xs' },
    xl: { img: 'w-24 h-24', text: 'text-3xl font-black tracking-tight', sub: 'text-sm' },
    '2xl': { img: 'w-32 h-32', text: 'text-4xl font-black tracking-tight', sub: 'text-base' },
  }[size];

  return (
    <div className={`inline-flex items-center gap-3 select-none ${className}`}>
      {/* Emblem Frame with Precision Edge */}
      <div className={`relative flex items-center justify-center shrink-0 overflow-hidden bg-panel p-1 border border-secondary/40 shadow-[0_0_15px_rgba(8,123,255,0.4)] transition-transform duration-200 aspect-square rounded-full ${dimensions.img}`}>
        <img
          src="/assets/aistudio/file_000000006914821196df3f2d2e60b066_3eb967aa.png"
          alt="flick staff apply"
          className="w-full h-full object-contain"
        />
      </div>

      {showText && (
        <div className="flex flex-col leading-none justify-center">
          <div className="flex items-center gap-1.5">
            <span className={`${dimensions.text} text-main tracking-wider font-black`}>
              flick
            </span>
            <span className={`${dimensions.sub} font-semibold text-secondary uppercase tracking-widest`}>
              staff apply
            </span>
          </div>
          <span className={`${dimensions.sub} tracking-widest font-medium text-muted uppercase mt-0.5`}>
            portal
          </span>
        </div>
      )}
    </div>
  );
};
