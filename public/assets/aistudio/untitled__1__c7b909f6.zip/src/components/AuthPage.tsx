import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { signInWithPopup } from 'firebase/auth';
import { auth, googleProvider } from '../lib/firebase';
import { FlickLogo } from './FlickLogo';
import { AlertCircle, ArrowRight, LogIn } from 'lucide-react';

interface AuthPageProps {
  onSuccess?: () => void;
  onContinueAsGuest?: () => void;
}

export const AuthPage: React.FC<AuthPageProps> = ({ onSuccess, onContinueAsGuest }) => {
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleGoogleAuth = async () => {
    setError(null);
    setLoading(true);
    try {
      await signInWithPopup(auth, googleProvider);
      if (onSuccess) onSuccess();
    } catch (err: any) {
      if (err?.code !== 'auth/popup-closed-by-user' && err?.code !== 'auth/cancelled-popup-request') {
        console.error('Google Auth Error:', err);
        setError(err.message || 'Google authentication failed.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen bg-canvas text-main flex flex-col items-center justify-center p-4 sm:p-6 relative overflow-hidden"
    >
      {/* Background ambient glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-to-tr from-primary/20 via-secondary/10 to-transparent rounded-full blur-[120px] pointer-events-none" />

      <motion.div
        initial={{ scale: 0.95, y: 10, opacity: 0 }}
        animate={{ scale: 1, y: 0, opacity: 1 }}
        transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
        className="w-full max-w-md bg-panel border border-secondary/20 rounded-[32px] p-8 sm:p-10 shadow-2xl relative z-10 space-y-8 backdrop-blur-sm"
      >
        {/* Logo & Header */}
        <div className="flex flex-col items-center text-center space-y-4">
          <div className="p-1 rounded-full bg-gradient-to-b from-panel to-canvas border border-secondary/40 shadow-[0_0_20px_rgba(8,123,255,0.3)]">
            <FlickLogo size="xl" showText={false} />
          </div>
          <div className="space-y-1">
            <h1 className="text-2xl font-black tracking-tight text-main uppercase italic">
              flick <span className="text-secondary">portal</span>
            </h1>
            <p className="text-xs text-muted font-medium tracking-wide">
              Official Staff Recruitment & Management
            </p>
          </div>
        </div>

        {/* Alert Notifications */}
        <AnimatePresence mode="wait">
          {error && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="p-4 bg-red-500/10 border border-red-500/20 rounded-2xl text-red-200 text-xs flex items-center gap-3 overflow-hidden"
            >
              <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
              <span>{error}</span>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Auth Actions */}
        <div className="space-y-4">
          <motion.button
            whileHover={{ scale: 1.02, translateY: -2 }}
            whileTap={{ scale: 0.98 }}
            onClick={handleGoogleAuth}
            disabled={loading}
            className="w-full bg-gradient-to-r from-primary to-secondary hover:from-blue-600 hover:to-cyan-500 text-white font-black py-4 rounded-2xl flex items-center justify-center gap-4 transition-all text-xs uppercase tracking-widest shadow-[0_8px_20px_rgba(8,123,255,0.25)] disabled:opacity-50"
          >
            <div className="bg-white p-1.5 rounded-lg shadow-sm">
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path
                  fill="#EA4335"
                  d="M12 5c1.6 0 3 .6 4.1 1.6l3.1-3.1C17.3 1.7 14.8 1 12 1 7.5 1 3.7 3.6 1.9 7.3l3.7 2.9C6.5 7.2 9 5 12 5z"
                />
                <path
                  fill="#4285F4"
                  d="M23.5 12.3c0-.8-.1-1.6-.2-2.3H12v4.5h6.5c-.3 1.5-1.1 2.8-2.4 3.7l3.7 2.9c2.2-2 3.7-5 3.7-8.8z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.6 14.8c-.2-.7-.4-1.5-.4-2.3s.2-1.6.4-2.3L1.9 7.3C.7 9.7 0 12.3 0 15s.7 5.3 1.9 7.7l3.7-2.9c-.8-1.5-1.2-3.2-1.2-5z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c3.2 0 6-1.1 8-3l-3.7-2.9c-1.1.7-2.5 1.2-4.3 1.2-3 0-5.5-2.2-6.4-5.2L1.9 16C3.7 19.7 7.5 23 12 23z"
                />
              </svg>
            </div>
            <span>{loading ? 'Connecting...' : 'Continue with Google'}</span>
          </motion.button>

          {onContinueAsGuest && (
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={onContinueAsGuest}
              className="w-full bg-canvas/50 hover:bg-canvas border border-secondary/20 text-muted hover:text-main font-bold py-4 rounded-2xl flex items-center justify-center gap-3 transition-all text-xs uppercase tracking-widest"
            >
              <span>Explore as Guest</span>
              <ArrowRight className="w-4 h-4" />
            </motion.button>
          )}
        </div>

        <div className="pt-4 text-center">
          <p className="text-[10px] text-muted uppercase tracking-[0.2em] font-bold">
            Secure · Official · Trusted
          </p>
        </div>
      </motion.div>
    </motion.div>
  );
};
