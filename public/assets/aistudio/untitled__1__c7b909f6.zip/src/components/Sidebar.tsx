import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, MessageSquare, Home, FileText, ClipboardList, MessageCircle, User } from 'lucide-react';
import { FlickLogo } from './FlickLogo';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  currentPage: string;
  onNavigate: (page: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ isOpen, onClose, currentPage, onNavigate }) => {
  const navItems = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'apply', label: 'Staff Apply', icon: FileText },
    { id: 'status', label: 'Application Status', icon: ClipboardList },
    { id: 'reports', label: 'Reports', icon: MessageCircle },
    { id: 'account', label: 'Account', icon: User },
    { id: 'discord', label: 'Join Discord', icon: MessageSquare },
  ];

  const DISCORD_URL = 'https://discord.gg/BRDwvqbFf';

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50"
          />
          <motion.aside
            initial={{ x: -300 }}
            animate={{ x: 0 }}
            exit={{ x: -300 }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed top-0 left-0 h-full w-80 bg-canvas border-r border-secondary/20 z-50 p-6 flex flex-col shadow-2xl"
          >
            <div className="flex items-center justify-between mb-8">
              <FlickLogo size="sm" showText={true} />
              <button onClick={onClose} className="p-2 rounded-xl bg-panel text-muted hover:text-main">
                <X className="w-5 h-5" />
              </button>
            </div>

            <nav className="flex-1 space-y-2 overflow-y-auto pr-2">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = currentPage === item.id;
                return (
                  <motion.button
                    key={item.id}
                    whileHover={{ x: 4 }}
                    onClick={() => {
                      if (item.id === 'discord') {
                        window.open(DISCORD_URL, '_blank', 'noopener,noreferrer');
                      } else {
                        onNavigate(item.id);
                      }
                      onClose();
                    }}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all ${
                      isActive
                        ? 'bg-primary/20 text-main border border-primary/30'
                        : 'text-muted hover:text-main hover:bg-panel'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    <span>{item.label}</span>
                  </motion.button>
                );
              })}
            </nav>
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  );
};
