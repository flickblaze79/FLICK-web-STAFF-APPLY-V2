import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { FlickLogo } from './FlickLogo';

interface SplashScreenProps {
  onComplete: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onComplete }) => {
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(false);
    }, 1800);

    const completeTimer = setTimeout(() => {
      onComplete();
    }, 2300);

    return () => {
      clearTimeout(timer);
      clearTimeout(completeTimer);
    };
  }, [onComplete]);

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 1 }}
          exit={{ opacity: 0, scale: 1.05 }}
          transition={{ duration: 0.5, ease: 'easeInOut' }}
          className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-canvas text-main"
        >
          <motion.div
            initial={{ scale: 0.8, opacity: 0, y: 10 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="flex flex-col items-center justify-center space-y-5 text-center"
          >
            <motion.div
              animate={{
                filter: [
                  'drop-shadow(0 0 10px rgba(8,123,255,0.4))',
                  'drop-shadow(0 0 25px rgba(0,217,255,0.6))',
                  'drop-shadow(0 0 10px rgba(8,123,255,0.4))',
                ],
              }}
              transition={{ repeat: Infinity, duration: 2, ease: 'easeInOut' }}
            >
              <FlickLogo size="2xl" showText={false} />
            </motion.div>

            <div className="text-center space-y-1.5">
              <h1 className="text-3xl font-black tracking-wider bg-gradient-to-r from-primary via-secondary to-blue-400 bg-clip-text text-transparent uppercase italic">
                flick staff apply
              </h1>
              <p className="text-[10px] font-bold text-muted uppercase tracking-[0.3em]">
                Official Portal
              </p>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
