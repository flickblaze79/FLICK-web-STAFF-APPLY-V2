import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Check, MessageCircle } from 'lucide-react';

interface SubmissionSuccessProps {
  isOpen: boolean;
  onClose: () => void;
  category: string;
}

export const SubmissionSuccess: React.FC<SubmissionSuccessProps> = ({ isOpen, onClose, category }) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="bg-zinc-950 border border-zinc-800 rounded-3xl p-8 max-w-sm w-full text-center shadow-2xl relative overflow-hidden"
          >
            {/* Glowing background */}
            <div className="absolute inset-0 bg-emerald-600/10 blur-3xl pointer-events-none" />
            
            <div className="relative z-10 flex flex-col items-center gap-6">
              <motion.div
                initial={{ scale: 0.5 }}
                animate={{ scale: 1 }}
                transition={{ type: 'spring', damping: 10, stiffness: 100 }}
                className="w-20 h-20 rounded-full bg-emerald-950 border-4 border-emerald-500/30 flex items-center justify-center"
              >
                <Check className="w-10 h-10 text-emerald-400" />
              </motion.div>

              <div className="space-y-2">
                <h2 className="text-xl font-black text-white uppercase">APPLICATION SUBMITTED!</h2>
                <p className="text-xs text-zinc-400">Your application has been successfully submitted.</p>
              </div>

              {category === 'Developer Application' && (
                <div className="bg-zinc-900 border border-indigo-900/50 p-4 rounded-xl text-xs space-y-3">
                  <p className="text-zinc-300">Application submitted! Open a Staff Apply ticket on Discord and share your portfolio to receive your final verdict.</p>
                  <a href="https://discord.gg/9RjefkV3S" target="_blank" rel="noopener noreferrer" className="flex items-center justify-center gap-2 w-full py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-lg transition-all">
                    <MessageCircle className="w-4 h-4" />
                    Discord
                  </a>
                </div>
              )}

              <div className="grid grid-cols-2 gap-4 w-full bg-zinc-900 p-4 rounded-xl text-xs">
                <div>
                  <div className="text-zinc-500 uppercase font-bold">Category</div>
                  <div className="text-white font-bold">{category}</div>
                </div>
                <div>
                  <div className="text-zinc-500 uppercase font-bold">Status</div>
                  <div className="text-amber-400 font-bold uppercase">Pending</div>
                </div>
              </div>

              <button
                onClick={onClose}
                className="w-full py-3 bg-white text-black font-black text-sm uppercase tracking-wider rounded-xl hover:bg-zinc-200 transition-all"
              >
                Continue
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
