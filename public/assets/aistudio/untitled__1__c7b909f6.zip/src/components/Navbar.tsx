import React from 'react';
import { motion } from 'motion/react';
import { useAuth } from '../context/AuthContext';
import { FlickLogo } from './FlickLogo';
import {
  Home,
  FileText,
  ClipboardList,
  MessageSquare,
  User,
  Shield,
  Hammer,
  Settings,
  Crown,
  Menu,
  LogOut,
  Bell,
  MessageCircle,
} from 'lucide-react';

interface NavbarProps {
  currentPage: string;
  onNavigate: (page: string) => void;
  onOpenAuth: () => void;
  onToggleSidebar: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentPage, onNavigate, onOpenAuth, onToggleSidebar }) => {
  const { currentUser, userProfile, isStaff, isMod, isAdmin, isOwner, logout } = useAuth();
  
  const DISCORD_URL = 'https://discord.gg/BRDwvqbFf';

  const handleNavClick = (page: string) => {
    onNavigate(page);
  };

  const handleDiscordClick = () => {
    window.open(DISCORD_URL, '_blank', 'noopener,noreferrer');
  };

  const mainNavItems = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'apply', label: 'Staff Apply', icon: FileText },
    { id: 'status', label: 'Application Status', icon: ClipboardList },
    { id: 'reports', label: 'Reports', icon: MessageCircle },
    { id: 'account', label: 'Account', icon: User },
  ];

  const panelNavItems = [
    ...(isStaff ? [{ id: 'staff-panel', label: 'Staff Panel', icon: Shield, badge: 'Staff' }] : []),
    ...(isMod ? [{ id: 'mod-panel', label: 'Mod Panel', icon: Hammer, badge: 'Mod' }] : []),
    ...(isAdmin ? [{ id: 'admin-panel', label: 'Admin Panel', icon: Settings, badge: 'Admin' }] : []),
    ...(isOwner ? [{ id: 'owner-panel', label: 'Owner Panel', icon: Crown, badge: 'Owner' }] : []),
  ];

  return (
    <header className="sticky top-0 z-40 bg-canvas/90 backdrop-blur-md border-b border-secondary/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-4">
            <button onClick={onToggleSidebar} className="p-2 rounded-xl text-zinc-300 hover:text-white hover:bg-zinc-800 border border-zinc-700/50">
                <Menu className="w-6 h-6" />
            </button>
            <motion.div
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="flex items-center gap-3 cursor-pointer select-none"
              onClick={() => handleNavClick('home')}
            >
              <FlickLogo size="md" showText={true} />
            </motion.div>
          </div>

          <nav className="hidden md:flex items-center gap-1.5">
            {mainNavItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentPage === item.id;
              return (
                <motion.button
                  key={item.id}
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.97 }}
                  onClick={() => handleNavClick(item.id)}
                  className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold transition-all relative ${
                    isActive
                      ? 'bg-zinc-800 text-white shadow-sm border border-zinc-700/80'
                      : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900/80'
                  }`}
                >
                  <Icon className="w-4 h-4 text-orange-400" />
                  <span>{item.label}</span>
                </motion.button>
              );
            })}

            <motion.button
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              onClick={handleDiscordClick}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold text-indigo-400 hover:text-indigo-300 hover:bg-indigo-950/40 border border-indigo-900/40 transition-all"
            >
              <MessageSquare className="w-4 h-4 text-indigo-400" />
              <span>Discord</span>
            </motion.button>

            {panelNavItems.length > 0 && (
              <div className="flex items-center gap-1.5 pl-2 ml-2 border-l border-zinc-800">
                {panelNavItems.map((panel) => {
                  const Icon = panel.icon;
                  const isActive = currentPage === panel.id;
                  return (
                    <motion.button
                      key={panel.id}
                      whileHover={{ scale: 1.04 }}
                      whileTap={{ scale: 0.96 }}
                      onClick={() => handleNavClick(panel.id)}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                        isActive
                          ? 'bg-gradient-to-r from-primary to-secondary text-white shadow-md border border-purple-500/50'
                          : 'bg-zinc-900 text-purple-400 hover:text-purple-300 hover:bg-zinc-800 border border-purple-900/30'
                      }`}
                    >
                      <Icon className="w-3.5 h-3.5 text-amber-400" />
                      <span>{panel.label}</span>
                    </motion.button>
                  );
                })}
              </div>
            )}
          </nav>

          <div className="hidden md:flex items-center gap-3">
            {currentUser ? (
              <div className="flex items-center gap-3">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => handleNavClick('notifications')}
                  className="p-2 rounded-xl text-zinc-400 hover:text-white hover:bg-zinc-900 border border-zinc-800 transition-colors relative"
                  title="Notifications"
                >
                  <Bell className="w-4 h-4" />
                </motion.button>

                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => handleNavClick('account')}
                  className="flex items-center gap-2.5 px-3 py-1.5 rounded-xl bg-zinc-900 border border-zinc-800 hover:border-zinc-700 transition-colors"
                >
                  <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-red-500 to-orange-500 flex items-center justify-center font-bold text-xs text-white">
                    {userProfile?.name?.charAt(0).toUpperCase() || 'U'}
                  </div>
                  <div className="flex flex-col text-left">
                    <span className="text-xs font-semibold text-zinc-200 leading-tight">
                      {userProfile?.name || 'Account'}
                    </span>
                    <span className="text-[10px] font-bold text-orange-400 uppercase tracking-widest leading-none mt-0.5">
                      {userProfile?.role || 'USER'}
                    </span>
                  </div>
                </motion.button>

                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={logout}
                  className="p-2 rounded-xl text-zinc-400 hover:text-red-400 hover:bg-zinc-900 border border-zinc-800 transition-colors"
                  title="Sign Out"
                >
                  <LogOut className="w-4 h-4" />
                </motion.button>
              </div>
            ) : (
              <motion.button
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.97 }}
                onClick={onOpenAuth}
                className="bg-gradient-to-r from-primary to-secondary hover:from-violet-500 hover:to-blue-500 text-white font-bold text-xs px-4 py-2 rounded-xl transition-all shadow-md shadow-violet-950/40"
              >
                Sign In / Register
              </motion.button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
