export type UserRole = 'USER' | 'STAFF' | 'MOD' | 'ADMIN' | 'OWNER';

export interface UserProfile {
  uid: string;
  name: string;
  email: string;
  photoURL?: string;
  role: UserRole;
  createdAt: string;
  lastSignInAt?: string;
  isSuspended?: boolean;
  suspensionReason?: string;
  suspensionDate?: string;
  suspendedBy?: string;
  roleAssignedAt?: string;
  roleAssignedBy?: string;
  providerId?: string;
}

export type ApplicationStatus = 'Pending' | 'Under Review' | 'Accepted' | 'Rejected';
export type ApplicationQueue = 'Staff Review' | 'Mod Review' | 'Admin Review';
export type ApplicationCategory = 'Staff Application' | 'Helper Application' | 'Developer Application';

export const QUESTIONS: Record<ApplicationCategory, string[]> = {
  'Staff Application': [
    "What is your Discord username?", "How old are you?", "What is your timezone?", "Which country do you live in?",
    "Do you have any previous staff experience? If yes, explain your responsibilities.",
    "What was your previous staff role, and on which server did you work?",
    "What are your biggest strengths and weaknesses?", "How will you help Flick Web?",
    "Why should we choose you over other applicants?", "How many hours per day or week can you be active on the server?",
    "If your friend breaks a server rule, what punishment or action will you take, and why?",
    "If you see a senior staff member breaking the rules and no other senior staff are online, what will you do?",
    "If two users are fighting, how will you handle the situation?",
    "State any three server rules in your own words and explain why they are important.",
    "If a sudden raid happens and you are the only staff member online, what will you do?",
    "Is there anything else you would like to tell us?"
  ],
  'Helper Application': [
    "What is your Discord username?", "How old are you?", "What is your timezone?", "Which country do you live in?",
    "Why do you want to become a Helper on Flick Web?",
    "How will you help users with their questions or issues?",
    "What are your strengths when interacting with users?",
    "How many hours per day or week can you be active on the server?",
    "If you see a user breaking the rules, what will you do?",
    "If two users are fighting, how will you handle the situation?",
    "Are you comfortable with the rules and guidelines of the server?",
    "Is there anything else you would like to tell us?"
  ],
  'Developer Application': [
    "What is your Discord username?",
    "How old are you?",
    "What is your timezone?",
    "Which country do you live in?",
    "How many years of development experience do you have?",
    "Which programming languages and technologies do you know?",
    "What types of projects have you developed before?",
    "Share links to your portfolio, GitHub, or previous projects.",
    "Why do you want to join the FLICK STAFF APPLY Developer Team?",
    "How much time can you dedicate each week?",
    "Are you comfortable working with a team and following project requirements?"
  ]
};

export interface StaffApplication {
  id?: string;
  applicantUid: string;
  applicantName: string;
  applicantEmail: string;
  discordUsername: string;
  discordUserId: string;
  age: string;
  timezone: string;
  availableHours: string;
  category: ApplicationCategory;
  position: string;
  answers: Record<string, string>;
  status: ApplicationStatus;
  queue: ApplicationQueue;
  assignedReviewerUid?: string;
  assignedReviewerName?: string;
  assignmentStatus?: 'Unassigned' | 'Assigned';
  assignedAt?: string;
  reviewerUid?: string;
  reviewerRole?: UserRole;
  reviewNotes?: string;
  createdAt: string;
  updatedAt: string;
}

export type ReportStatus = 'Open' | 'Reviewing' | 'Resolved' | 'Rejected';

export interface UserReport {
  id?: string;
  authorUid: string;
  authorName: string;
  authorEmail: string;
  reportType: string;
  subject: string;
  description: string;
  status: ReportStatus;
  assignedToUid?: string;
  resolutionNotes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface NotificationItem {
  id?: string;
  recipientUid: string;
  title: string;
  message: string;
  type: 'application' | 'report' | 'system' | 'role';
  read: boolean;
  createdAt: string;
}

export interface AuditLogEntry {
  id?: string;
  action: string;
  actorUid: string;
  actorName: string;
  actorEmail: string;
  actorRole: UserRole;
  targetResource: string;
  targetUid?: string;
  timestamp: string;
  metadata?: Record<string, any>;
}

export interface SystemSettings {
  applicationsOpen: boolean;
  announcementText: string;
  requirementsText: string;
  positions: string[];
  updatedAt: string;
}
