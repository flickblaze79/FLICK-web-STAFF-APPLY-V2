import React, { createContext, useContext, useEffect, useState } from 'react';
import { User, onAuthStateChanged, signOut, updateProfile as firebaseUpdateProfile } from 'firebase/auth';
import { doc, getDoc, setDoc, updateDoc } from 'firebase/firestore';
import { auth, db, handleFirestoreError, OperationType } from '../lib/firebase';
import { UserProfile, UserRole } from '../types';

interface AuthContextType {
  currentUser: User | null;
  userProfile: UserProfile | null;
  loading: boolean;
  isStaff: boolean;
  isMod: boolean;
  isAdmin: boolean;
  isOwner: boolean;
  logout: () => Promise<void>;
  updateDisplayName: (name: string) => Promise<void>;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const OWNER_EMAILS = ['nxtawais95@gmail.com', 'lostawais1@gmail.com'];

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchOrCreateProfile = async (user: User) => {
    const userDocRef = doc(db, 'users', user.uid);
    try {
      const snap = await getDoc(userDocRef);
      const isOwnerEmail = !!user.email && OWNER_EMAILS.some((e) => e.toLowerCase() === user.email?.toLowerCase());

      if (snap.exists()) {
        const data = snap.data() as UserProfile;
        
        // Auto-boost owner email if needed
        if (isOwnerEmail && data.role !== 'OWNER') {
          const updatedProfile: UserProfile = { ...data, role: 'OWNER' };
          await setDoc(userDocRef, updatedProfile, { merge: true });
          setUserProfile(updatedProfile);
        } else {
          setUserProfile(data);
        }
      } else {
        // Create new user profile in Firestore
        const initialRole: UserRole = isOwnerEmail ? 'OWNER' : 'USER';

        const newProfile: UserProfile = {
          uid: user.uid,
          name: user.displayName || user.email?.split('@')[0] || 'User',
          email: user.email || '',
          photoURL: user.photoURL || '',
          role: initialRole,
          createdAt: new Date().toISOString(),
          isSuspended: false,
          providerId: user.providerData[0]?.providerId || 'password',
        };

        await setDoc(userDocRef, newProfile);
        setUserProfile(newProfile);
      }
    } catch (err) {
      console.error('Error fetching/creating user profile:', err);
      const isOwnerEmail = !!user.email && OWNER_EMAILS.some((e) => e.toLowerCase() === user.email?.toLowerCase());
      const fallbackRole: UserRole = isOwnerEmail ? 'OWNER' : 'USER';
      setUserProfile({
        uid: user.uid,
        name: user.displayName || user.email?.split('@')[0] || 'User',
        email: user.email || '',
        photoURL: user.photoURL || '',
        role: fallbackRole,
        createdAt: new Date().toISOString(),
        isSuspended: false,
      });
    }
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      if (user) {
        await fetchOrCreateProfile(user);
      } else {
        setUserProfile(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const logout = async () => {
    await signOut(auth);
    setUserProfile(null);
  };

  const updateDisplayName = async (name: string) => {
    if (!currentUser) return;
    await firebaseUpdateProfile(currentUser, { displayName: name });
    const userDocRef = doc(db, 'users', currentUser.uid);
    try {
      await updateDoc(userDocRef, { name });
      if (userProfile) {
        setUserProfile({ ...userProfile, name });
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${currentUser.uid}`);
    }
  };

  const refreshProfile = async () => {
    if (currentUser) {
      await fetchOrCreateProfile(currentUser);
    }
  };

  const role = userProfile?.role || 'USER';
  const isStaff = role === 'STAFF' || role === 'MOD' || role === 'ADMIN' || role === 'OWNER';
  const isMod = role === 'MOD' || role === 'ADMIN' || role === 'OWNER';
  const isAdmin = role === 'ADMIN' || role === 'OWNER';
  const isOwner = role === 'OWNER';

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        userProfile,
        loading,
        isStaff,
        isMod,
        isAdmin,
        isOwner,
        logout,
        updateDisplayName,
        refreshProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
