# Security Specification & Test Suites for FLICK STAFF APPLY

## 1. Data Invariants
- **Users**: Users can read their own profile. Changing role fields is forbidden on self-update.
- **Applications**: Applicants can create and read their own applications. Only STAFF/MOD/ADMIN/OWNER can read/review/update applications based on status/role scope.
- **Reports**: Authors can create and read their own reports. Staff/Mod/Admin/Owner can read and manage reports.
- **Notifications**: Users can read/update (`read: true`) their own notifications.
- **Audit Logs**: Clients cannot directly edit or delete audit logs. STAFF/MOD/ADMIN/OWNER can read audit logs depending on permission tier.

## 2. Dirty Dozen Attack Payloads
1. User role spoofing on registration (`role: "OWNER"`).
2. User attempting to elevate their own role (`role: "ADMIN"`).
3. Normal user attempting to list all staff applications (`/applications`).
4. Applicant attempting to approve their own application (`status: "Accepted"`).
5. User trying to read another user's application (`applicantUid: "otherUser"`).
6. User injecting 5MB text block into application experience fields.
7. Disallowed client modifying `audit_logs` entries directly.
8. Unauthenticated user writing to `/reports` without valid auth credentials.
9. Non-admin attempting to update global `/system_settings`.
10. Unverified email user attempting privileged operations.
11. Disallowed user deleting `/users/{userId}` profile document.
12. Staff member attempting to grant OWNER or ADMIN privileges to another user.
